# QLearningAgent.py
import numpy as np
import random
import pickle
import os
import tqdm
from tqdm import tqdm
import copy
from datetime import datetime


class QLearningAgent:
    def __init__(self,
                 state_size,
                 action_size,
                 grid_size_x,
                 grid_size_y,
                 grid_size_z,
                 learning_rate=0.1,
                 discount_rate=0.9,
                 exploration_rate=1.0,
                 exploration_decay=0.995,
                 model_save_path="qlearning_model.pkl"):
        self.state_size = state_size
        self.action_size = action_size
        self.grid_size_x = grid_size_x
        self.grid_size_y = grid_size_y
        self.grid_size_z = grid_size_z

        self.learning_rate = learning_rate
        self.discount_rate = discount_rate
        self.exploration_rate = exploration_rate
        self.exploration_decay = exploration_decay

        self.q_table = {}
        self.model_save_path = model_save_path

        self.step_counter = 0
        self.last_action = None
        self.action_history = []
        self.history_size = 5

        # Histories for plotting
        self.rewards_history = []
        self.lr_history = []
        self.exploration_history = []

        # NEW: Keep track of how many steps each episode took
        self.steps_history = []
        self.time_history = []

    def get_q_value(self, state, action):
        state_tuple = tuple(sorted(state))
        return self.q_table.get((state_tuple, action), 0.0)

    def update_q_value(self, state, action, reward, next_state):
        state_tuple = tuple(sorted(state))
        next_state_tuple = tuple(sorted(next_state))

        possible_actions = self.possible_actions(next_state_tuple)
        max_future_q = max([self.get_q_value(next_state_tuple, a) for a in possible_actions] or [0.0])

        current_q = self.get_q_value(state_tuple, action)
        new_q = current_q + self.learning_rate * (reward + self.discount_rate * max_future_q - current_q)
        self.q_table[(state_tuple, action)] = new_q

    def possible_actions(self, state):
        _, adj_pairs = self.env.get_adjacent_entities()
        return adj_pairs

    def choose_action(self, state, env):
        self.env = env
        _, adj_pairs = env.get_adjacent_entities()
        if not adj_pairs:
            return None
        best_pair = None
        best_value = float('-inf')
        for pair in adj_pairs:
            q_value = self.get_q_value(state, pair)
            if q_value > best_value:
                best_value = q_value
                best_pair = pair
        if best_pair is None:
            # fallback random
            return random.choice(adj_pairs)
        else:
            return best_pair

    def save_model(self, path):
        import os
        dir_name = os.path.dirname(path)
        if dir_name and not os.path.exists(dir_name):
            os.makedirs(dir_name)
        with open(path, 'wb') as file:
            pickle.dump(self.q_table, file)

    def load_model(self, path):
        try:
            with open(path, 'rb') as file:
                self.q_table = pickle.load(file)
        except FileNotFoundError:
            print(f"No model found at {path}, starting from scratch.")
        except Exception as e:
            print(f"Failed to load model: {e}. Starting from scratch.")
