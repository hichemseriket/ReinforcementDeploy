# Polyvoxels.py
import numpy as np
import matplotlib.pyplot as plt
from .Voxel import Voxel


class Polyvoxels:
    _id_counter = 1

    def __init__(self, voxels):
        self.voxels = voxels
        self.id = Polyvoxels._id_counter
        Polyvoxels._id_counter += 1

    def get_coordinates(self):
        """
        Retourne les coordonnées moyennes (centroïde) de ce polyvoxel.
        Utile pour l’affichage, la visualisation, etc.
        """
        avg_x = sum(voxel.x for voxel in self.voxels) / len(self.voxels)
        avg_y = sum(voxel.y for voxel in self.voxels) / len(self.voxels)
        avg_z = sum(voxel.z for voxel in self.voxels) / len(self.voxels)
        return (avg_x, avg_y, avg_z)

    def add_voxel(self, voxel):
        """Ajoute un voxel dans la liste s’il n’y est pas déjà."""
        if voxel not in self.voxels:
            self.voxels.append(voxel)

    def find_neighbors(self, grid):
        """
        Trouve les voisins de ce polyvoxel (unique_neighbors)
        en inspectant les voisins de chacun de ses voxels.
        """
        unique_neighbors = set()
        for voxel in self.voxels:
            neighbors = voxel.find_neighbors(grid)
            unique_neighbors.update(neighbors)
        # On retire du set tous les voxels qui appartiennent déjà à ce polyvoxel
        unique_neighbors.difference_update(self.voxels)
        return list(unique_neighbors)

    def calculate_dof_polyvoxel(self, all_voxels, all_polyvoxels=None):
        """
        Calcule le DOF du polyvoxel.
        On peut faire une logique similaire à celle d’un voxel,
        mais qui considère l’ensemble des faces libres autour du polyvoxel.
        """
        if all_polyvoxels is None:
            all_polyvoxels = []

        # 6 faces possibles : ±x, ±y, ±z
        dof_flags = {'+x': True, '-x': True, '+y': True, '-y': True, '+z': True, '-z': True}
        directions = {
            '+x': (1, 0, 0), '-x': (-1, 0, 0),
            '+y': (0, 1, 0), '-y': (0, -1, 0),
            '+z': (0, 0, 1), '-z': (0, 0, -1)
        }

        # On parcourt les voxels du polyvoxel
        for voxel in self.voxels:
            for direction, (dx, dy, dz) in directions.items():
                neighbor = next(
                    (v for v in all_voxels
                     if v.x == voxel.x + dx and
                     v.y == voxel.y + dy and
                     v.z == voxel.z + dz),
                    None
                )
                if neighbor is not None:
                    dof_flags[direction] = False

        return sum(dof_flags.values())

    def can_translate_out(self, grid_size_x, grid_size_y, grid_size_z):
        """
        Vérifie s’il existe un déplacement possible (même minime)
        pour « sortir » le polyvoxel de la grille.
        Ici, on se contente de dire :
        - S’il y a de la place dans au moins une des 6 directions globales (±x, ±y, ±z),
          on considère qu’il peut être inséré/désassemblé.
        """
        directions = {
            '+x': (1, 0, 0), '-x': (-1, 0, 0),
            '+y': (0, 1, 0), '-y': (0, -1, 0),
            '+z': (0, 0, 1), '-z': (0, 0, -1)
        }

        for dx, dy, dz in directions.values():
            can_translate_in_this_dir = True
            for voxel in self.voxels:
                nx = voxel.x + dx
                ny = voxel.y + dy
                nz = voxel.z + dz
                # Si un seul voxel sort de la grille, on considère que c’est pas forcément bon
                # ou on pourrait considérer : "il existe dx,dy,dz > X qui le libère"
                if not (0 <= nx < grid_size_x and
                        0 <= ny < grid_size_y and
                        0 <= nz < grid_size_z):
                    can_translate_in_this_dir = False
                    break

            if can_translate_in_this_dir:
                return True

        return False

    def can_merge_with_voxel(self, voxel):
        """Vérifie si on peut fusionner ce polyvoxel avec un voxel isolé."""
        for v in self.voxels:
            if v.can_merge_with(voxel):
                return True
        return False

    def can_merge_with_polyvoxel(self, other_polyvoxel):
        """Vérifie si on peut fusionner ce polyvoxel avec un autre."""
        for v in self.voxels:
            for ov in other_polyvoxel.voxels:
                if v.can_merge_with(ov):
                    return True
        return False

    def visualize(self, ax, color='blue'):
        """Affiche les voxels qui composent ce polyvoxel."""
        for voxel in self.voxels:
            Voxel.plot_cube(voxel.x, voxel.y, voxel.z, ax, color=color)

    def __eq__(self, other):
        return isinstance(other, Polyvoxels) and set(self.voxels) == set(other.voxels)

    def __hash__(self):
        return hash(tuple(sorted(self.voxels, key=lambda v: (v.x, v.y, v.z))))

    def __repr__(self):
        return f"Polyvoxels({self.voxels})"

    def can_be_easily_disassembled(self):
        """
        Logique simplifiée :
        - Chaque voxel du polyvoxel doit avoir au moins une face libre
          (i.e., qui ne touche pas un autre voxel du polyvoxel).
        """
        for voxel in self.voxels:
            if not self.has_free_face(voxel):
                return False
        return True

    def has_free_face(self, voxel):
        directions = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
        for dx, dy, dz in directions:
            if not any((voxel.x + dx == v.x and
                        voxel.y + dy == v.y and
                        voxel.z + dz == v.z)
                       for v in self.voxels):
                return True
        return False

    @staticmethod
    def plot_polyvoxels(polyvoxels_list, ax):
        """Affiche une liste de polyvoxels sur un même Axes3D."""
        colors = plt.cm.jet(np.linspace(0, 1, len(polyvoxels_list)))
        for polyvoxel, c in zip(polyvoxels_list, colors):
            for voxel in polyvoxel.voxels:
                Voxel.plot_cube(voxel.x, voxel.y, voxel.z, ax, size=1, color=c)
