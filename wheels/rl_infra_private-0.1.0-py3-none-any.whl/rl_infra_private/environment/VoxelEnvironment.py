# classe VoxelEnvironment.py
import os
import csv
import math
from collections import deque
from datetime import datetime
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from collections import deque

from .Voxel import Voxel
from .Polyvoxels import Polyvoxels


class VoxelEnvironment:
    def __init__(self, max_polyvoxel_size=400, max_steps=2000):
        self.grid_size_x = 0
        self.grid_size_y = 0
        self.grid_size_z = 0
        self.max_polyvoxel_size = max_polyvoxel_size
        self.max_steps = max_steps  # A safety cap to avoid infinite loops

        self.grid = None
        self.polyvoxels = []

        self.current_dof = 0
        self.step_counter = 0
        self.assembly_sequence = []

        # NOUVEAU : on stocke le path pour pouvoir recharger dans reset()
        self.csv_path = None

    def normalize_points(self, points):
        """
        Vérifie si la liste de points (tuples (x, y, z)) est positionnée à partir de l'origine.
        Si le minimum d'au moins un axe est différent de 0, décale tous les points de sorte que
        le point ayant la coordonnée minimale devienne (0, 0, 0).

        Paramètres:
          points (list of tuple): Liste des points sous forme (x, y, z).

        Retourne:
          list of tuple: La liste des points normalisés.
        """
        if not points:
            return points

        # Calcul des minima sur chaque axe
        min_x = min(pt[0] for pt in points)
        min_y = min(pt[1] for pt in points)
        min_z = min(pt[2] for pt in points)

        # Si les points commencent déjà à l'origine, on ne fait rien
        if min_x == 0 and min_y == 0 and min_z == 0:
            return points

        # Sinon, on décale chaque point pour que le minimum devienne 0
        normalized_points = [(pt[0] - min_x, pt[1] - min_y, pt[2] - min_z) for pt in points]
        return normalized_points


    def load_points_from_csv(self, file_path):
        """
        Lit un fichier CSV contenant des coordonnées (x,y,z) au format {x,y,z} ou x,y,z.
        Crée la grille "serrée" exactement autour des voxels et place un voxel à chaque coordonnée.
        On suppose ici que les points du CSV commencent déjà à l'origine.
        """
        self.csv_path = file_path  # On mémorise le chemin pour reset()

        points = []
        with open(file_path, 'r') as f:
            for line in f:
                line = line.strip().strip('{}')
                if not line:
                    continue
                try:
                    x_str, y_str, z_str = line.split(',')
                    x, y, z = float(x_str), float(y_str), float(z_str)
                    points.append((x, y, z))
                except ValueError:
                    print(f"[WARN] Ligne CSV invalide : {line}")

        if not points:
            print("[WARN] Aucun point trouvé dans le CSV.")
            return

        # Puisque le CSV commence déjà à l'origine, on n'applique pas de décalage.
        min_x = 0
        min_y = 0
        min_z = 0
        max_x = max(pt[0] for pt in points)
        max_y = max(pt[1] for pt in points)
        max_z = max(pt[2] for pt in points)

        self.grid_size_x = int(max_x) + 1
        self.grid_size_y = int(max_y) + 1
        self.grid_size_z = int(max_z) + 1

        # Créer la grille vide (taille exactement ajustée aux points)
        self.grid = [
            [
                [None for _ in range(self.grid_size_z)]
                for _ in range(self.grid_size_y)
            ]
            for _ in range(self.grid_size_x)
        ]

        # Placer les voxels dans la grille en utilisant directement les coordonnées lues
        for (px, py, pz) in points:
            gx = int(px)  # Pas de décalage nécessaire
            gy = int(py)
            gz = int(pz)
            if (0 <= gx < self.grid_size_x and
                    0 <= gy < self.grid_size_y and
                    0 <= gz < self.grid_size_z):
                self.grid[gx][gy][gz] = Voxel(gx, gy, gz)

        self.polyvoxels = []
        self.current_dof = self.calculate_total_dof()
        self.step_counter = 0
        self.assembly_sequence = []

        print(f"[INFO] {len(points)} points lus depuis {file_path}. "
              f"Grille=({self.grid_size_x},{self.grid_size_y},{self.grid_size_z}). "
              f"DOF initial = {self.current_dof}.")



    def reset(self):
        """
        Avant, on créait une grille vide. Désormais, on re-relit le CSV
        pour restaurer l'état initial à chaque épisode.
        """
        if self.csv_path:
            self.load_points_from_csv(self.csv_path)
        else:
            print("[WARN] reset() appelé sans csv_path.")
        return self.get_state()

    def get_state(self):
        """
        Retourne la liste triée (x,y,z) de toutes les entités
        (voxels isolés + polyvoxels).
        """
        state = []

        # 1) Voxels isolés
        if self.grid:
            for x_slice in self.grid:
                for y_slice in x_slice:
                    for item in y_slice:
                        if isinstance(item, Voxel):
                            state.append((item.x, item.y, item.z))
                        # sinon, si c'est un Polyvoxels, on l'ignore ici
                        # (pour éviter 'item.x' sur un objet Polyvoxels)

        # 2) Polyvoxels
        for poly in self.polyvoxels:
            for v in poly.voxels:
                state.append((v.x, v.y, v.z))

        return sorted(state)

    def flatten_grid(self):
        return [
            voxel
            for x_slice in self.grid
            for y_slice in x_slice
            for voxel in y_slice
            if voxel is not None
        ]

    def calculate_total_dof(self):
        """
        Calcule la somme des DOF pour chaque entité (voxel seul ou polyvoxel).
        """
        entities = self.get_entities()
        total_dof = 0
        for e in entities:
            if isinstance(e, Voxel):
                total_dof += self._dof_for_voxel_as_piece(e)
            else:
                total_dof += self._dof_for_polyvoxel_as_piece(e)
        return total_dof

    def _dof_for_voxel_as_piece(self, voxel):
        directions = [
            (1,0,0), (-1,0,0),
            (0,1,0), (0,-1,0),
            (0,0,1), (0,0,-1)
        ]
        dof = 0
        for dx, dy, dz in directions:
            if self._can_move_voxel(voxel, dx, dy, dz):
                dof += 1
        return dof


    def _can_move_voxel(self, voxel, dx, dy, dz):
        nx = voxel.x + dx
        ny = voxel.y + dy
        nz = voxel.z + dz
        # Si le voisin est hors limites, considérer ce déplacement comme libre
        if not (0 <= nx < self.grid_size_x and 0 <= ny < self.grid_size_y and 0 <= nz < self.grid_size_z):
            return True
        neighbor = self.grid[nx][ny][nz]
        return neighbor is None

    def _dof_for_polyvoxel_as_piece(self, poly):
        directions = [(1, 0, 0), (-1, 0, 0),
                      (0, 1, 0), (0, -1, 0),
                      (0, 0, 1), (0, 0, -1)]
        dof = 0
        for (dx, dy, dz) in directions:
            can_move = self._can_move_polyvoxel(poly, dx, dy, dz)
            # print(f"[DEBUG] poly={poly.id}, direction=({dx},{dy},{dz}), can_move={can_move}")
            if can_move:
                dof += 1
        return dof

    def _can_move_polyvoxel(self, poly, dx, dy, dz):
        for v in poly.voxels:
            nx = v.x + dx
            ny = v.y + dy
            nz = v.z + dz
            if not (0 <= nx < self.grid_size_x and
                    0 <= ny < self.grid_size_y and
                    0 <= nz < self.grid_size_z):
                return False
            neighbor = self.grid[nx][ny][nz]
            if neighbor is not None:
                if isinstance(neighbor, Voxel):
                    if neighbor not in poly.voxels:
                        return False
                elif isinstance(neighbor, Polyvoxels):
                    if neighbor != poly:
                        return False
        return True

    def get_entities(self):
        """
        Renvoie la liste : [voxel isolé, ..., polyvoxel, ...].
        """
        entities = []
        # Voxels isolés
        for x in range(self.grid_size_x):
            for y in range(self.grid_size_y):
                for z in range(self.grid_size_z):
                    item = self.grid[x][y][z]
                    if isinstance(item, Voxel):
                        entities.append(item)
        # Polyvoxels
        entities.extend(self.polyvoxels)
        return entities

    def are_adjacent_entities(self, e1, e2):
        if isinstance(e1, Polyvoxels):
            vox_e1 = e1.voxels
        else:
            vox_e1 = [e1]

        if isinstance(e2, Polyvoxels):
            vox_e2 = e2.voxels
        else:
            vox_e2 = [e2]

        for v1 in vox_e1:
            for v2 in vox_e2:
                if abs(v1.x - v2.x) + abs(v1.y - v2.y) + abs(v1.z - v2.z) == 1:
                    return True
        return False

    def get_adjacent_entities(self):
        ents = self.get_entities()
        adj_pairs = []
        for i in range(len(ents)):
            for j in range(i+1, len(ents)):
                if self.are_adjacent_entities(ents[i], ents[j]):
                    adj_pairs.append((i, j))
        return ents, adj_pairs

    def can_merge(self, e1, e2):
        size1 = len(e1.voxels) if isinstance(e1, Polyvoxels) else 1
        size2 = len(e2.voxels) if isinstance(e2, Polyvoxels) else 1
        if (size1 + size2) > self.max_polyvoxel_size:
            return False
        return True

    def merge_voxels(self, e1, e2):
        # 1) Récupérer les voxels
        if isinstance(e1, Polyvoxels):
            vox1 = e1.voxels[:]
        else:
            vox1 = [e1]

        if isinstance(e2, Polyvoxels):
            vox2 = e2.voxels[:]
        else:
            vox2 = [e2]

        new_poly = Polyvoxels(vox1 + vox2)

        # 2) Retirer e1 et e2 (les cases de la grille deviennent None si c'étaient des Voxel)
        self.remove_entity(e1)
        self.remove_entity(e2)

        # 3) Vérifier la sortie du nouveau poly (ou toute autre condition)
        if not self.can_polyvoxel_exit_grid(new_poly):
            # revert
            self.re_add_entity(e1)
            self.re_add_entity(e2)
            return None

        # 4) Ajouter le nouveau polyvoxel à la liste
        self.polyvoxels.append(new_poly)

        # 5) Vérifier que tous les polyvoxels restent "sortables"
        for p in self.polyvoxels:
            if not self.can_polyvoxel_exit_grid(p):
                # revert si besoin
                self.polyvoxels.remove(new_poly)
                self.re_add_entity(e1)
                self.re_add_entity(e2)
                return None

        # 6) (NOUVEAU) Placer le polyvoxel dans la grille
        #    Chaque voxel interne pointe vers 'new_poly'
        #    pour que la grille sache qu'il est occupé.
        for v in new_poly.voxels:
            self.grid[v.x][v.y][v.z] = new_poly

        # 7) Mettre à jour la séquence d'assemblage et retourner
        self.assembly_sequence.append((e1, e2, new_poly))
        return new_poly

    def remove_entity(self, entity):
        if isinstance(entity, Voxel):
            if self.grid[entity.x][entity.y][entity.z] == entity:
                self.grid[entity.x][entity.y][entity.z] = None
        elif isinstance(entity, Polyvoxels):
            if entity in self.polyvoxels:
                self.polyvoxels.remove(entity)

    def re_add_entity(self, entity):
        if isinstance(entity, Voxel):
            if self.grid[entity.x][entity.y][entity.z] is None:
                self.grid[entity.x][entity.y][entity.z] = entity
        else:
            if entity not in self.polyvoxels:
                self.polyvoxels.append(entity)

    def all_outside_grid(self, positions):
        for (x, y, z) in positions:
            if 0 <= x < self.grid_size_x and 0 <= y < self.grid_size_y and 0 <= z < self.grid_size_z:
                return False
        return True

    def can_polyvoxel_exit_grid(self, poly):
        start_positions = frozenset((v.x, v.y, v.z) for v in poly.voxels)
        if self.all_outside_grid(start_positions):
            return True

        # Construit obstacles (les autres polyvoxels et voxels hors poly)
        obstacles = set()
        for p in self.polyvoxels:
            if p != poly:
                for v in p.voxels:
                    obstacles.add((v.x, v.y, v.z))
        for x in range(self.grid_size_x):
            for y in range(self.grid_size_y):
                for z in range(self.grid_size_z):
                    it = self.grid[x][y][z]
                    if it is not None:
                        if isinstance(it, Voxel):
                            if (x, y, z) not in start_positions:
                                obstacles.add((x, y, z))

        queue = deque([start_positions])
        visited = set([start_positions])
        directions = [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]

        while queue:
            current = queue.popleft()
            for (dx, dy, dz) in directions:
                new_positions = []
                can_move = True
                for (cx, cy, cz) in current:
                    nx, ny, nz = cx+dx, cy+dy, cz+dz
                    if (0 <= nx < self.grid_size_x and
                        0 <= ny < self.grid_size_y and
                        0 <= nz < self.grid_size_z):
                        if (nx, ny, nz) in obstacles and (nx, ny, nz) not in current:
                            can_move = False
                            break
                    new_positions.append((nx, ny, nz))
                if not can_move:
                    continue
                new_positions = frozenset(new_positions)
                if self.all_outside_grid(new_positions):
                    return True
                if new_positions not in visited:
                    visited.add(new_positions)
                    queue.append(new_positions)
        return False

    def calculate_reward(self, dof_before, dof_after, new_poly=None):
        import math
        # Calcul de la variation de DOF
        diff = dof_before - dof_after
        if diff > 0:
            base_reward = 30.0 * diff
        else:
            base_reward = -1.0

        # Malus pour trop de polyvoxels
        malus_for_many_poly = -0.5 * (len(self.polyvoxels) - math.ceil(
            self.grid_size_x * self.grid_size_y * self.grid_size_z / self.max_polyvoxel_size))

        # Si un nouveau polyvoxel est créé, on calcule les termes supplémentaires
        if new_poly is not None:
            # f_sort : 1 si le polyvoxel est sortable, 0 sinon.
            f_sort = 1 if self.can_polyvoxel_exit_grid(new_poly) else 0

            # f_compact : mesure de la compacité = nombre_effectif_voxels / volume_bounding_box
            xs = [v.x for v in new_poly.voxels]
            ys = [v.y for v in new_poly.voxels]
            zs = [v.z for v in new_poly.voxels]
            width = max(xs) - min(xs) + 1
            height = max(ys) - min(ys) + 1
            depth = max(zs) - min(zs) + 1
            bounding_box_volume = width * height * depth
            f_compact = len(new_poly.voxels) / bounding_box_volume if bounding_box_volume > 0 else 0

            # f_size : mesure de la proximité à la taille maximale souhaitée
            current_size = len(new_poly.voxels)
            f_size = 1 - abs(self.max_polyvoxel_size - current_size) / self.max_polyvoxel_size
        else:
            f_sort = 0
            f_compact = 0
            f_size = 0

        # Coefficients de pondération (à ajuster expérimentalement)
        c2 = 8.0  # Pour la sortabilité
        c3 = 0  # Pour la compacité
        c4 = 0  # Pour la taille

        # Pénalité supplémentaire si le polyvoxel n'est pas sortable
        penalty = 15.0 if f_sort == 0 else 0.0

        # Calcul du bonus supplémentaire
        extra_reward = c2 * f_sort + c3 * f_compact + c4 * f_size - penalty

        # Récompense finale
        reward = base_reward + malus_for_many_poly + extra_reward
        return reward


    def step(self, action):
        """
        Executes one merge action in the environment. Returns:
          - next_state
          - reward
          - done (True if episode should end, else False)
        """

        # 1) Retrieve all current entities
        ents = self.get_entities()
        i, j = action

        # 2) Check if indices are valid
        if i >= len(ents) or j >= len(ents):
            # Invalid indexing => negative reward, but don't terminate
            return self.get_state(), -3.0, False

        e1 = ents[i]
        e2 = ents[j]

        # 3) Check if merge is allowed (size constraints, etc.)
        if not self.can_merge(e1, e2):
            # Negative reward, but continue
            return self.get_state(), -1.0, False

        dof_before = self.current_dof

        # 4) Attempt to merge
        new_poly = self.merge_voxels(e1, e2)
        if new_poly is None:
            # Merge was reverted => negative reward, but do NOT end the episode
            return self.get_state(), -2.0, False

        # 5) If successful merge
        dof_after = self.calculate_total_dof()
        self.current_dof = dof_after

        # 6) Compute reward
        reward = self.calculate_reward(dof_before, dof_after, new_poly)

        # 7) Increment step counter
        self.step_counter += 1

        # 8) Check if we should terminate
        #    (a) DOF <= target
        #    (b) no possible merges left
        #    (c) or safety limit reached
        done = self.check_done(target_dof=3)

        next_state = self.get_state()
        return next_state, reward, done

    def check_done(self, target_dof=3):
        if self.current_dof <= target_dof:
            print("[DEBUG] Done because DOF <=", target_dof)
            return True
        if self.no_possible_actions():
            print("[DEBUG] Done because no merges remain.")
            return True
        if self.step_counter >= self.max_steps:
            print("[DEBUG] Done because step_counter >= max_steps.")
            return True
        return False

    def no_possible_actions(self):
        """
        Returns True if no adjacent pairs remain, i.e., no merges possible.
        """
        _, adj_pairs = self.get_adjacent_entities()
        return len(adj_pairs) == 0


    def write_polyvoxels_to_csv(self, index, output_dir):
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        file_path = os.path.join(output_dir, f'Polyvoxels_{index}_{timestamp}.csv')

        csv_data = [["Polyvoxel ID", "Voxel X", "Voxel Y", "Voxel Z"]]
        for poly_id, polyvoxel in enumerate(self.polyvoxels, start=1):
            for voxel in polyvoxel.voxels:
                csv_data.append([f"Polyvoxel_{poly_id}", voxel.x, voxel.y, voxel.z])

        with open(file_path, mode='w', newline='') as f:
            import csv
            writer = csv.writer(f)
            writer.writerows(csv_data)
        print(f"[INFO] Wrote polyvoxels CSV -> {file_path}")

    def disassemble_sequence(self):
        remaining = list(self.polyvoxels)
        disassembly_order = []
        while remaining:
            found_piece = False
            for poly in remaining:
                if self.can_polyvoxel_exit_grid(poly):
                    found_piece = True
                    disassembly_order.append(poly)
                    remaining.remove(poly)
                    self.remove_entity(poly)
                    break
            if not found_piece:
                return None
        return disassembly_order


    def visualize(self, ax=None, show=True):
        """
        Affiche la configuration voxelisée et les polyvoxels en 3D,
        en centrant la vue sur la zone réellement occupée (les voxels présents)
        et en forçant un aspect ratio 1:1:1. Le titre indique le
        fichier CSV, le DOF final et le nombre de polyvoxels.

        Paramètres:
          - ax: Axes3D sur lequel dessiner. Si None, une nouvelle figure est créée.
          - show: Si True, appelle plt.show() à la fin.
        """
        import numpy as np
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D
        from .Polyvoxels import Polyvoxels
        from .Voxel import Voxel
        import os

        # Création de la figure et de l'axe si non fournis
        if ax is None:
            fig = plt.figure(figsize=(14, 14))
            ax = fig.add_subplot(111, projection='3d')
        else:
            fig = ax.get_figure()

        # --- 1) Récupération des coordonnées réellement occupées ---
        all_coords = []
        # Si des polyvoxels existent, on utilise leurs voxels
        if self.polyvoxels:
            for poly in self.polyvoxels:
                for v in poly.voxels:
                    all_coords.append((v.x, v.y, v.z))
        # Sinon, on parcourt la grille et on ne collecte que les voxels placés
        if not all_coords:
            for x in range(self.grid_size_x):
                for y in range(self.grid_size_y):
                    for z in range(self.grid_size_z):
                        item = self.grid[x][y][z]
                        if isinstance(item, Voxel):
                            all_coords.append((x, y, z))

        if not all_coords:
            print("[WARN] Aucune coordonnée occupée, rien à afficher.")
            return

        # Extraire les coordonnées et calculer les bornes
        xs = [c[0] for c in all_coords]
        ys = [c[1] for c in all_coords]
        zs = [c[2] for c in all_coords]

        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        min_z, max_z = min(zs), max(zs)

        # Ajouter une petite marge autour de l'objet (ajustable)
        margin = 1.0
        min_x -= margin
        max_x += margin
        min_y -= margin
        max_y += margin
        min_z -= margin
        max_z += margin

        # --- 2) Tracer les éléments ---
        # Tracer les polyvoxels (couleurs distinctes)
        Polyvoxels.plot_polyvoxels(self.polyvoxels, ax)
        # Tracer les voxels simples en gris
        for x in range(self.grid_size_x):
            for y in range(self.grid_size_y):
                for z in range(self.grid_size_z):
                    v = self.grid[x][y][z]
                    if isinstance(v, Voxel):
                        Voxel.plot_cube(v.x, v.y, v.z, ax, color='gray')

        # --- 3) Définir les limites d'affichage selon la zone occupée ---
        ax.set_xlim3d([min_x, max_x])
        ax.set_ylim3d([min_y, max_y])
        ax.set_zlim3d([min_z, max_z])
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')

        # --- 4) Forcer un aspect ratio 1:1:1 basé sur ces limites ---
        def set_axes_equal(ax):
            """Force l'aspect 1:1:1, en se basant sur les limites calculées."""
            x_limits = ax.get_xlim3d()
            y_limits = ax.get_ylim3d()
            z_limits = ax.get_zlim3d()

            x_range = abs(x_limits[1] - x_limits[0])
            y_range = abs(y_limits[1] - y_limits[0])
            z_range = abs(z_limits[1] - z_limits[0])
            max_range = max(x_range, y_range, z_range)

            x_mid = (x_limits[0] + x_limits[1]) / 2
            y_mid = (y_limits[0] + y_limits[1]) / 2
            z_mid = (z_limits[0] + z_limits[1]) / 2

            ax.set_xlim3d([x_mid - max_range / 2, x_mid + max_range / 2])
            ax.set_ylim3d([y_mid - max_range / 2, y_mid + max_range / 2])
            ax.set_zlim3d([z_mid - max_range / 2, z_mid + max_range / 2])

        set_axes_equal(ax)

        # --- 5) Titre ---
        csv_name = os.path.basename(self.csv_path) if hasattr(self, 'csv_path') and self.csv_path else "NoCSV"
        nb_poly = len(self.polyvoxels)
        dof_final = self.current_dof
        fig.suptitle(
            f"File: {csv_name}  |  Polyvoxels: {nb_poly}  |  DOF: {dof_final}",
            fontsize=14, fontweight='bold'
        )

        if show:
            plt.show()
        else:
            plt.close()




