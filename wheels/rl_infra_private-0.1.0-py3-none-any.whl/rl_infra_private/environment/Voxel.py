# Voxel.py
import numpy as np
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

class Voxel:
    def __init__(self, x, y, z, id=None):
        self.x = x
        self.y = y
        self.z = z
        # identifiant optionnel
        self.id = id if id is not None else f'{x}-{y}-{z}'
        self.neighbors = []

    def find_neighbors(self, grid):
        """
        Trouve les voisins directs (±x, ±y, ±z) dans la grille.
        """
        neighbors = []
        directions = [(0,1,0), (0,-1,0), (1,0,0), (-1,0,0), (0,0,1), (0,0,-1)]
        for dx, dy, dz in directions:
            nx, ny, nz = self.x + dx, self.y + dy, self.z + dz
            if (0 <= nx < len(grid) and
                0 <= ny < len(grid[0]) and
                0 <= nz < len(grid[0][0])):
                neighbor = grid[nx][ny][nz]
                if neighbor is not None:
                    neighbors.append(neighbor)
        return neighbors

    def calculate_dof(self, grid):
        """
        Calcule un DOF local :
        On retire le nombre de neighbors (jusqu’à 6)
        ou toute autre logique que vous voulez.
        """
        if not self.neighbors:
            self.neighbors = self.find_neighbors(grid)
        return 6 - len(self.neighbors)

    def is_on_edge(self, grid_size_x, grid_size_y, grid_size_z):
        """
        Vérifie si ce voxel est sur la bordure de la grille.
        """
        return (self.x == 0 or self.x == grid_size_x - 1 or
                self.y == 0 or self.y == grid_size_y - 1 or
                self.z == 0 or self.z == grid_size_z - 1)

    @staticmethod
    def plot_cube(x, y, z, ax, size=1, color='blue'):
        """
        Dessine un petit cube représentant le voxel.
        """
        vertices = np.array([
            [x,       y,       z      ],
            [x+size,  y,       z      ],
            [x+size,  y+size,  z      ],
            [x,       y+size,  z      ],
            [x,       y,       z+size],
            [x+size,  y,       z+size],
            [x+size,  y+size,  z+size],
            [x,       y+size,  z+size]
        ])

        faces = [
            vertices[[0,1,2,3]], # Bas
            vertices[[4,5,6,7]], # Haut
            vertices[[0,3,7,4]], # Face gauche
            vertices[[1,2,6,5]], # Face droite
            vertices[[0,1,5,4]], # Face avant
            vertices[[2,3,7,6]]  # Face arrière
        ]
        for face in faces:
            poly = Poly3DCollection([face], color=color, linewidths=1, edgecolors='r')
            poly.set_alpha(0.25)
            ax.add_collection3d(poly)

    def can_merge_with(self, other_voxel):
        """
        Logique possible pour déterminer si deux voxels peuvent fusionner.
        Ici, on pourrait exiger qu’ils soient voisins, par exemple.
        """
        dist = abs(self.x - other_voxel.x) + abs(self.y - other_voxel.y) + abs(self.z - other_voxel.z)
        return dist == 1

    def __eq__(self, other):
        return isinstance(other, Voxel) and (self.x, self.y, self.z) == (other.x, other.y, other.z)

    def __hash__(self):
        return hash((self.x, self.y, self.z))

    def __repr__(self):
        return f"Voxel({self.x}, {self.y}, {self.z})"
