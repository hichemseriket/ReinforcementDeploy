# classe Trainer.py
import os
import copy
from datetime import datetime
import time
from tqdm import tqdm

# Import your plotting functions
from src.plotting.plotting import (
    plot_voxel_environment,
    plot_q_value_vs_step,
    plot_training_history,
    plot_reward_and_steps,
    plot_time_history,
    plot_dof_evolution_10Epiosdes,
    plot_dof_evolution,
    plot_action_indices,
    save_action_history, plot_blocks_and_dof_dual_axis
)

class Trainer:
    def __init__(self, agent, env, episodes=1000, max_steps=100,
                 checkpoint_interval=100, log_interval=10,
                 output_csv_dir='results',
                 disassembly_dir='results/disassembly',
                 plot_every_episode=False,
                 episode_plots_dir='results/episode_plots'):
        """
        Initialise le Trainer avec l'agent, l'environnement et les paramètres d'entraînement.
        Si plot_every_episode est True, un plot de l'état et d'autres métriques sera sauvegardé
        à chaque épisode dans episode_plots_dir.
        """
        self.agent = agent
        self.env = env
        self.episodes = episodes
        self.max_steps = max_steps
        self.checkpoint_interval = checkpoint_interval
        self.log_interval = log_interval
        self.output_csv_dir = output_csv_dir
        self.disassembly_dir = disassembly_dir
        self.plot_every_episode = plot_every_episode
        self.episode_plots_dir = episode_plots_dir

        # Stockage des historiques par épisode
        self.episode_dof_history = []       # Liste de listes : DOF à chaque étape
        self.episode_actions_history = []   # Liste de listes : actions choisies (tuples) par étape
        self.episode_q_history = []         # Liste de listes : Q-value de l'action choisie à chaque étape
        self.interlocking_blocks_history = []

        os.makedirs(self.output_csv_dir, exist_ok=True)
        os.makedirs(self.disassembly_dir, exist_ok=True)
        if self.plot_every_episode:
            os.makedirs(self.episode_plots_dir, exist_ok=True)

    def train(self):
        """
        Exécute la boucle d'entraînement pour un nombre spécifié d'épisodes.
        """
        patience = 60
        improvement_threshold = 1e-3
        no_improvement_count = 0
        best_reward = -float('inf')
        total_training_time = 0.0

        for episode in tqdm(range(self.episodes), desc="Training Episodes", ncols=100):
            start_time = time.time()
            state = self.env.reset()
            total_reward = 0
            done = False

            dof_list = []
            action_list = []
            episode_q_history = []

            # We can track steps with a second tqdm if desired
            for step in range(self.max_steps):
                action = self.agent.choose_action(state, self.env)
                if action is None:
                    break
                # Q-value before update
                q_val = self.agent.get_q_value(state, action)
                episode_q_history.append(q_val)

                next_state, reward, done = self.env.step(action)
                self.agent.update_q_value(state, action, reward, next_state)
                total_reward += reward

                # DOF now
                dof_now = self.env.current_dof
                dof_list.append(dof_now)

                action_list.append(action)
                state = next_state

                if done or self.env.check_done():
                    break

            self.episode_dof_history.append(dof_list)
            self.episode_actions_history.append(action_list)
            self.episode_q_history.append(episode_q_history)
            # À la fin de chaque épisode, enregistrer le nombre de polyvoxels créés
            self.interlocking_blocks_history.append(len(self.env.polyvoxels))

            episode_time = time.time() - start_time
            total_training_time += episode_time
            avg_step_time = episode_time / (step + 1) if (step + 1) > 0 else 0.0

            # Update agent logs
            self.agent.time_history.append(episode_time)
            self.agent.rewards_history.append(total_reward)
            self.agent.lr_history.append(self.agent.learning_rate)
            self.agent.exploration_history.append(self.agent.exploration_rate)
            self.agent.steps_history.append(len(dof_list))

            # Logging
            if (episode+1) % self.log_interval == 0:
                tqdm.write(
                    f"Episode {episode+1}: Reward = {total_reward:.2f}, "
                    f"Steps = {step+1}, Time = {episode_time:.2f}s, AvgStepTime = {avg_step_time:.4f}s"
                )

            # Q-table stats
            q_values = list(self.agent.q_table.values())
            if len(q_values) > 0:
                policy_stat = 100.0 * sum(1 for q in q_values if q > 0) / len(q_values)
            else:
                policy_stat = 0.0
            if (episode+1) % self.log_interval == 0:
                tqdm.write(f"Ep {episode+1}: Q(>0) = {policy_stat:.1f}%")

            # Decay rates
            self.agent.exploration_rate = max(self.agent.exploration_rate * self.agent.exploration_decay, 0.01)
            self.agent.learning_rate = max(self.agent.learning_rate * 0.999, 0.001)

            # Patience mechanism
            if total_reward > best_reward + improvement_threshold:
                best_reward = total_reward
                no_improvement_count = 0
            else:
                no_improvement_count += 1

            # if no_improvement_count >= patience:
            #     tqdm.write(f"[INFO] Convergence: no improvement for {patience} episodes. Stopping.")
            #     break

            # Check if puzzle is disassemblable
            env_clone = copy.deepcopy(self.env)
            disassembly = env_clone.disassemble_sequence()
            polyvoxel_count = len(self.env.polyvoxels)
            final_dof = self.env.calculate_total_dof()
            folder_suffix = f"_{polyvoxel_count}pv_{final_dof}dof"

            if disassembly is not None:
                tqdm.write(f"[INFO] Ep {episode+1}: Disassemblable! Reward = {total_reward:.2f}")
                tqdm.write(f"DOF: {final_dof}, Polyvoxels: {polyvoxel_count}")

                # Save CSV of the configuration
                self.env.write_polyvoxels_to_csv(episode, self.output_csv_dir)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                disas_filename = os.path.join(
                    self.disassembly_dir,
                    f"disassembly_{episode+1}_{timestamp}{folder_suffix}.txt"
                )
                with open(disas_filename, "w", encoding="utf-8") as f:
                    for i, poly in enumerate(disassembly, start=1):
                        f.write(f"Step {i}: remove {poly}\n")

                # If we want to plot environment or Q-values every time we find a solution:
                if self.plot_every_episode:
                    state_plot_path = os.path.join(
                        self.episode_plots_dir,
                        f"episode_{episode+1}_state{folder_suffix}.png"
                    )
                    plot_voxel_environment(self.env, show=False, save_path=state_plot_path)

            # Save checkpoint
            if (episode+1) % self.checkpoint_interval == 0:
                self.agent.save_model(self.agent.model_save_path)
                tqdm.write(f"[Checkpoint] Ep {episode+1}, Reward = {total_reward:.2f}")

        self.agent.save_model(self.agent.model_save_path)
        tqdm.write("[INFO] Training finished.")
        tqdm.write(f"Total training time: {total_training_time:.2f}s")

        # Optionally generate final plots
        self.generate_plots_after_training()

    def generate_plots_after_training(self):
        """
        Generates final plots for reward, steps, DOF evolution, etc., after training.
        This avoids having to do it in main.py
        """
        final_dir = os.path.join(self.episode_plots_dir, "final_plots")
        os.makedirs(final_dir, exist_ok=True)

        # 1) Voxel Environment
        env_dir = os.path.join(final_dir, "voxel_env")
        os.makedirs(env_dir, exist_ok=True)
        env_plot_path = os.path.join(env_dir, "final_voxel_env.png")
        env_csv_path = os.path.join(env_dir, "final_voxel_env.csv")  # ou "env_data.csv"
        plot_voxel_environment(self.env, show=False,
                               save_path=env_plot_path,
                               csv_path=env_csv_path)

        # 2) Training history
        train_hist_dir = os.path.join(final_dir, "training_history")
        os.makedirs(train_hist_dir, exist_ok=True)
        train_hist_path = os.path.join(train_hist_dir, "training_history.png")
        train_hist_csv = os.path.join(train_hist_dir, "training_history.csv")
        plot_training_history(self.agent, show=False,
                              save_path=train_hist_path,
                              csv_path=train_hist_csv)

        # 3) Reward & Steps
        reward_steps_dir = os.path.join(final_dir, "reward_and_steps")
        os.makedirs(reward_steps_dir, exist_ok=True)
        reward_steps_path = os.path.join(reward_steps_dir, "reward_and_steps.png")
        reward_steps_csv = os.path.join(reward_steps_dir, "reward_and_steps.csv")
        plot_reward_and_steps(self.agent, show=False,
                              save_path=reward_steps_path,
                              csv_path=reward_steps_csv)

        # 4) Time history
        time_hist_dir = os.path.join(final_dir, "time_history")
        os.makedirs(time_hist_dir, exist_ok=True)
        time_hist_path = os.path.join(time_hist_dir, "time_history.png")
        time_hist_csv = os.path.join(time_hist_dir, "time_history.csv")
        plot_time_history(self.agent, show=False,
                          save_path=time_hist_path,
                          csv_path=time_hist_csv)

        # 5) DOF evolution (all episodes)
        dof_all_dir = os.path.join(final_dir, "dof_evolution_all")
        os.makedirs(dof_all_dir, exist_ok=True)
        dof_evo_path = os.path.join(dof_all_dir, "dof_evolution.png")
        dof_evo_csv = os.path.join(dof_all_dir, "dof_evolution.csv")
        plot_dof_evolution(self.episode_dof_history, show=False,
                           save_path=dof_evo_path,
                           csv_path=dof_evo_csv)

        # 6) DOF evolution (every 10 episodes)
        dof_10_dir = os.path.join(final_dir, "dof_evolution_10ep")
        os.makedirs(dof_10_dir, exist_ok=True)
        dof_evo_10_path = os.path.join(dof_10_dir, "dof_evolution_10episodes.png")
        dof_evo_10_csv = os.path.join(dof_10_dir, "dof_evolution_10episodes.csv")
        plot_dof_evolution_10Epiosdes(self.episode_dof_history, show=False,
                                      save_path=dof_evo_10_path,
                                      csv_path=dof_evo_10_csv)

        # 7) Action indices
        action_idx_dir = os.path.join(final_dir, "action_indices")
        os.makedirs(action_idx_dir, exist_ok=True)
        action_idx_path = os.path.join(action_idx_dir, "action_indices.png")
        action_idx_csv = os.path.join(action_idx_dir, "action_indices.csv")
        plot_action_indices(self.episode_actions_history, show=False,
                            save_path=action_idx_path,
                            csv_path=action_idx_csv)

        # 8) Q-value vs step for each episode
        q_vs_step_dir = os.path.join(final_dir, "q_vs_step")
        os.makedirs(q_vs_step_dir, exist_ok=True)
        for ep_idx, q_history in enumerate(self.episode_q_history):
            save_path = os.path.join(q_vs_step_dir, f'episode_{ep_idx + 1}_q_vs_step.png')
            csv_path = os.path.join(q_vs_step_dir, f'episode_{ep_idx + 1}_q_vs_step.csv')
            plot_q_value_vs_step(q_history, ep_idx + 1, show=False,
                                 save_path=save_path,
                                 csv_path=csv_path)

            # --- 9) Interlocking Blocks & Final DOF par épisode ---
            # Calcul du DOF final pour chaque épisode (dernier DOF de chaque liste)
            dof_final = [dofs[-1] for dofs in self.episode_dof_history]

            blocks_dof_dir = os.path.join(final_dir, 'blocks_and_dof')
            os.makedirs(blocks_dof_dir, exist_ok=True)
            plot_blocks_and_dof_dual_axis(
                self.interlocking_blocks_history,
                dof_final,
                target_dof=3,
                show=False,
                save_path=os.path.join(blocks_dof_dir, 'blocks_and_dof_dual.png'),
                csv_path=os.path.join(blocks_dof_dir, 'blocks_and_dof_dual.csv')
            )
        # Save action history in CSV
        actions_csv_path = os.path.join(final_dir, "action_history.csv")
        save_action_history(self.episode_actions_history, actions_csv_path)

        print("All final plots and CSVs have been generated.")


