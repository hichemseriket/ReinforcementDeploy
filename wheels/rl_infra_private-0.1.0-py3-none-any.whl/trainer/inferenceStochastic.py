import os
import random
import numpy as np
import copy
from datetime import datetime
from tqdm import tqdm  # progress bar

# Import de votre environnement et agent
from src.environment.VoxelEnvironment import VoxelEnvironment
from src.agent.QLearningAgent import QLearningAgent

# Fonctions de plotting si besoin
from src.plotting.plotting import (
    plot_voxel_environment,
    plot_q_value_histogram,
    plot_time_history
)

def set_seed(seed):
    """Set random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    # Ajoutez ici d'autres initialisations de seed si nécessaire (torch, etc.).

def run_model_inference(
    model_path,
    csv_path,
    safety_max_steps=1000,
    seed=None,
    result_dir="Results_Inference"
):
    """
    Exécute le modèle Q-learning en mode inférence sur un nouvel environnement.
    - L’exploration est désactivée (exploration_rate=0) pour utiliser la politique apprise.
    - On s’arrête soit quand l’environnement renvoie done=True, soit quand on dépasse
      un certain nombre de pas (safety_max_steps).
    - On sauvegarde ensuite les résultats (métriques, CSV, visualisations, etc.) dans un
      sous-dossier propre à chaque seed.
    """

    if seed is not None:
        set_seed(seed)

    # Créer un sous-dossier pour cette seed
    seed_folder = os.path.join(result_dir, f"seed_{seed}")
    os.makedirs(seed_folder, exist_ok=True)

    # 1) Créer un nouvel environnement et charger les données CSV
    env = VoxelEnvironment(max_polyvoxel_size=150, max_steps=2000)
    # Remarque : max_steps=2000 dans l'environnement => 'done=True' si step_counter >= 2000

    env.load_points_from_csv(csv_path)

    # 2) Déterminer la taille de grille pour configurer l'agent
    gx, gy, gz = env.grid_size_x, env.grid_size_y, env.grid_size_z

    # 3) Créer un agent Q-learning pour l'inférence, SANS exploration
    agent = QLearningAgent(
        state_size=gx * gy * gz,
        action_size=gx * gy * gz,
        grid_size_x=gx,
        grid_size_y=gy,
        grid_size_z=gz,
        learning_rate=0.1,       # pas vraiment utilisé en inférence
        discount_rate=0.9,
        exploration_rate=0.0,    # exploration désactivée
        exploration_decay=1.0,   # pas de décroissance
        model_save_path=model_path
    )

    # 4) Charger la Q-table entraînée
    agent.load_model(model_path)

    # 5) Réinitialiser l'environnement
    state = env.reset()
    total_reward = 0
    done = False
    step = 0

    # Mesurer le temps d'exécution
    start_time = datetime.now()

    # Barre de progression sur safety_max_steps
    pbar = tqdm(total=safety_max_steps, desc="Inference steps", ncols=100)

    while not done and step < safety_max_steps:
        action = agent.choose_action(state, env)

        if action is None:
            print("No valid actions available => plus de merges possibles.")
            break

        # Exécuter l'action
        next_state, reward, done = env.step(action)
        total_reward += reward
        state = next_state
        step += 1

        # Optionnel: debug pour voir le DOF et le nb de merges restants
        merges_left = len(env.get_adjacent_entities()[1])
        print(
            f"[DEBUG] step={step}, DOF={env.current_dof}, merges_left={merges_left}, "
            f"reward={reward:.2f}, done={done}"
        )

        pbar.update(1)

    pbar.close()

    # Fin de l'épisode (soit done=True, soit step>=safety_max_steps)
    end_time = datetime.now()
    episode_duration = (end_time - start_time).total_seconds()

    final_dof = env.calculate_total_dof()
    print(f"Inference finished after {step} steps with total reward: {total_reward:.2f}")
    print(f"Final DOF: {final_dof}")
    print(f"Episode duration: {episode_duration:.2f} seconds")

    # 6) Sauvegarde des métriques
    metrics_filename = os.path.join(seed_folder, "metrics.txt")
    with open(metrics_filename, "w", encoding="utf-8") as mf:
        mf.write(f"Steps: {step}\n")
        mf.write(f"Total Reward: {total_reward}\n")
        mf.write(f"Final DOF: {final_dof}\n")
        mf.write(f"Episode Duration (s): {episode_duration:.2f}\n")

    # 7) Vérifier la désassemblabilité
    env_clone = copy.deepcopy(env)
    disassembly = env_clone.disassemble_sequence()
    if disassembly is None:
        print("The assembled structure is NOT fully disassemblable.")
    else:
        print("The assembled structure is fully disassemblable.")
        disas_filename = os.path.join(seed_folder, f"disassembly_sequence_seed{seed}.txt")
        with open(disas_filename, "w", encoding="utf-8") as f:
            for i, poly in enumerate(disassembly, start=1):
                f.write(f"Step {i}: remove {poly}\n")

    # 8) Sauvegarder la configuration finale en CSV
    csv_filename = os.path.join(seed_folder, f"inference_result_seed{seed}.csv")
    env.write_polyvoxels_to_csv(step, csv_filename)

    # 9) Visualisation finale (optionnelle)
    final_image_path = os.path.join(seed_folder, "final_voxel_env.png")
    plot_voxel_environment(env, show=False, save_path=final_image_path)

    # 10) Histogramme des Q-values (optionnel)
    qhist_image_path = os.path.join(seed_folder, "final_qhist.png")
    plot_q_value_histogram(agent, episode=step, show=False, save_path=qhist_image_path)

    # 11) Courbe de temps (pour cette unique "épisode" d'inférence)
    agent.time_history = [episode_duration]
    time_image_path = os.path.join(seed_folder, "time_history.png")
    plot_time_history(agent, show=False, save_path=time_image_path)

    # 12) Affichage interactif (si besoin)
    env.visualize()


if __name__ == "__main__":
    # Chemin vers le CSV
    csv_path = "D:/PycharmProjects/renforcementPolyvoxels/dataInput/DATAPointsCSV/newSphereTrancheVide.csv"

    # Chemin vers le modèle Q-learning déjà entraîné
    # model_path = "../../models/qlearning_demo.pkl"
    model_path = "models/ToyotaComplexeSpace.pkl"

    # Nombre max de steps en inférence (sécurité)
    safety_max_steps = 100

    # Dossier pour stocker les résultats
    result_dir = "Results_Inference"

    # Lancer l’inférence sur plusieurs seeds
    for i in range(5):
        seed = i
        print(f"Running inference test {i+1} with seed {seed}")
        run_model_inference(
            model_path=model_path,
            csv_path=csv_path,
            safety_max_steps=safety_max_steps,
            seed=seed,
            result_dir=result_dir
        )
