# classe plotting.py
import matplotlib.pyplot as plt
import os
import csv
import numpy as np
from mpl_toolkits.mplot3d import Axes3D  # Needed for 3D plotting

def plot_voxel_environment(voxel_env, show=True, save_path=None, csv_path=None):
    """
    Visualizes the voxel environment and optionally saves the plot.
    Also optionally saves data in CSV form.
    NOTE: This depends on the environment's 'visualize()' method. 
          We then adjust the axes for a nicer look.
    """
    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(111, projection='3d')

    # Let the environment do its drawing, but we direct it to this Axes3D if possible.
    # If your environment’s visualize() method creates a new figure on its own,
    # you might need to modify it so it accepts 'ax' or returns it.
    # For now, we do something like:
    voxel_env.visualize(ax=ax)

    # Force axis ranges to [0, grid_size].
    ax.set_xlim(0, voxel_env.grid_size_x)
    ax.set_ylim(0, voxel_env.grid_size_y)
    ax.set_zlim(0, voxel_env.grid_size_z)

    # Make the aspect ratio equal so the cube is not stretched.
    # This might not always be perfect in matplotlib, but it helps:
    ax.set_box_aspect((voxel_env.grid_size_x,
                       voxel_env.grid_size_y,
                       voxel_env.grid_size_z))

    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    # ax.set_title("Voxel Environment")

    if save_path is not None:
        directory = os.path.dirname(save_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        plt.savefig(save_path)

    if csv_path is not None:
        # Example: Save each voxel’s (x,y,z) in a CSV if you want
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            # On ne met plus "voxel_value"
            writer.writerow(["x", "y", "z"])
            for pv in voxel_env.polyvoxels:
                for vox in pv.voxels:
                    # On ne met plus vox.value
                    writer.writerow([vox.x, vox.y, vox.z])

    if show:
        plt.show()
    else:
        plt.close()


def plot_reward_and_steps(agent, show=True, save_path=None, csv_path=None):
    """
    Plots two side-by-side curves:
      - Cumulative reward per episode
      - Number of steps per episode
    Optionally saves data in a CSV file.
    """
    episodes = range(len(agent.rewards_history))

    plt.figure(figsize=(10, 4))

    # Left: Cumulative Reward
    plt.subplot(1, 2, 1)
    plt.plot(episodes, agent.rewards_history, label='Cumulative Reward', color='blue')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    # plt.title('Cumulative Reward per Episode')
    plt.legend(loc='upper right')

    # Right: Steps per Episode
    plt.subplot(1, 2, 2)
    plt.plot(episodes, agent.steps_history, color='orange', label='Steps per Episode')
    plt.xlabel('Episode')
    plt.ylabel('Steps')
    plt.title('Steps per Episode')
    plt.legend(loc='upper right')

    plt.tight_layout()

    # Save figure
    if save_path:
        directory = os.path.dirname(save_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        plt.savefig(save_path)

    # Save CSV data
    if csv_path:
        directory = os.path.dirname(csv_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Episode", "Reward", "Steps"])
            for i in range(len(episodes)):
                writer.writerow([i, agent.rewards_history[i], agent.steps_history[i]])

    if show:
        plt.show()
    else:
        plt.close()


def plot_q_value_vs_step(q_value_history, episode_number, show=False, save_path=None, csv_path=None):
    """
    Plots the chosen Q-value vs step for a single episode.
    Optionally saves data in a CSV file.
    """
    steps = range(1, len(q_value_history) + 1)

    plt.figure(figsize=(8, 6))
    plt.plot(steps, q_value_history, marker='o', linestyle='-', color='blue')
    plt.xlabel("Step")
    plt.ylabel("Chosen Action Q-Value")
    # plt.title(f"Q-Value Evolution - Episode {episode_number}")

    if save_path:
        directory = os.path.dirname(save_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        plt.savefig(save_path)

    if csv_path:
        directory = os.path.dirname(csv_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Step", "QValue"])
            for step_idx, qv in enumerate(q_value_history, start=1):
                writer.writerow([step_idx, qv])

    if show:
        plt.show()
    else:
        plt.close()


def plot_training_history(agent, show=True, save_path=None, csv_path=None):
    """
    Plots three side-by-side curves:
      - Total reward per episode,
      - Learning rate,
      - Exploration rate.
    Optionally saves data in a CSV file.
    """
    episodes = range(len(agent.rewards_history))

    plt.figure(figsize=(14, 4))

    # Reward
    plt.subplot(1, 3, 1)
    plt.plot(episodes, agent.rewards_history, marker='o', label='Total Reward')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title('Reward per Episode')
    plt.legend(loc='upper right')

    # Learning rate
    plt.subplot(1, 3, 2)
    plt.plot(episodes, agent.lr_history, marker='o', color='orange', label='Learning Rate')
    plt.xlabel('Episode')
    plt.ylabel('Learning Rate')
    plt.title('Learning Rate Evolution')
    plt.legend(loc='upper right')

    # Exploration rate
    plt.subplot(1, 3, 3)
    plt.plot(episodes, agent.exploration_history, marker='o', color='green', label='Exploration Rate')
    plt.xlabel('Episode')
    plt.ylabel('Exploration Rate')
    # plt.title('Exploration Rate Evolution')
    plt.legend(loc='upper right')

    plt.tight_layout()

    if save_path:
        directory = os.path.dirname(save_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        plt.savefig(save_path)

    if csv_path:
        directory = os.path.dirname(csv_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Episode", "Reward", "LearningRate", "ExplorationRate"])
            for i in range(len(episodes)):
                writer.writerow([
                    i,
                    agent.rewards_history[i],
                    agent.lr_history[i],
                    agent.exploration_history[i]
                ])

    if show:
        plt.show()
    else:
        plt.close()


def plot_time_history(agent, show=True, save_path=None, csv_path=None):
    """
    Plots the time (in seconds) taken per episode.
    Optionally saves data in a CSV file.
    """
    episodes = range(len(agent.time_history))

    plt.figure(figsize=(10, 8))
    plt.plot(episodes, agent.time_history, marker='o', color='purple', label='Time per Episode')
    plt.xlabel('Episode')
    plt.ylabel('Time (s)')
    # plt.title('Episode Duration')
    plt.legend(loc='upper right')
    plt.tight_layout()

    if save_path:
        directory = os.path.dirname(save_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        plt.savefig(save_path)

    if csv_path:
        directory = os.path.dirname(csv_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Episode", "Time_s"])
            for i in range(len(episodes)):
                writer.writerow([i, agent.time_history[i]])

    if show:
        plt.show()
    else:
        plt.close()


def plot_dof_evolution_10Epiosdes(
    episode_dof_history,
    target_dof=3,
    show=False,
    save_path=None,
    csv_path=None
):
    import matplotlib.pyplot as plt
    import os
    import csv

    if save_path is not None:
        directory = os.path.dirname(save_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)

    plt.figure(figsize=(10, 6))

    # ➜ Ne tracer que les épisodes multiples de 10
    for ep_index, dofs in enumerate(episode_dof_history, start=1):
        if ep_index % 10 == 0:
            steps = range(len(dofs))
            plt.plot(steps, dofs, label=f"Episode {ep_index}")

    # ➜ Ligne horizontale "Target DOF"
    plt.axhline(y=target_dof, color='red', linestyle='--', linewidth=1.5,
                label=f"Target DOF = {target_dof}")

    plt.xlabel("Step")
    plt.ylabel("DOF")
    # plt.title("DOF Evolution (Every 10th Episode) with Target DOF")
    plt.legend(loc="upper right")
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path)

    if csv_path:
        directory = os.path.dirname(csv_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Episode", "Step", "DOF"])
            for ep_index, dofs in enumerate(episode_dof_history, start=1):
                if ep_index % 10 == 0:
                    for step_index, dof_val in enumerate(dofs):
                        writer.writerow([ep_index, step_index, dof_val])

    if show:
        plt.show()
    else:
        plt.close()


def plot_dof_evolution(
    episode_dof_history,
    target_dof=3,
    show=False,
    save_path=None,
    csv_path=None
):
    import matplotlib.pyplot as plt
    import os
    import csv

    if save_path is not None:
        directory = os.path.dirname(save_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)

    plt.figure(figsize=(10, 6))

    for ep_index, dofs in enumerate(episode_dof_history, start=1):
        steps = range(len(dofs))
        plt.plot(steps, dofs, label=f"Episode {ep_index}")

    # ➜ Ligne horizontale
    plt.axhline(y=target_dof, color='red', linestyle='--', linewidth=1.5,
                label=f"Target DOF = {target_dof}")

    plt.xlabel("Step")
    plt.ylabel("DOF")
    # plt.title("DOF Evolution per Episode (All)")
    # plt.legend(loc='upper right')
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path)

    if csv_path:
        directory = os.path.dirname(csv_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Episode", "Step", "DOF"])
            for ep_index, dofs in enumerate(episode_dof_history, start=1):
                for step_index, dof_val in enumerate(dofs):
                    writer.writerow([ep_index, step_index, dof_val])

    if show:
        plt.show()
    else:
        plt.close()


def plot_action_indices(episode_actions_history, show=True, save_path=None, csv_path=None):
    import matplotlib.pyplot as plt
    import os
    import csv

    if save_path is not None:
        directory = os.path.dirname(save_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)

    plt.figure(figsize=(14, 12))

    # ➜ Dé-commentez pour tracer les actions
    for ep_index, actions in enumerate(episode_actions_history, start=1):
        # On encode (i,j) en un entier pour avoir une courbe
        action_nums = [i * 1000 + j for (i, j) in actions]
        steps = range(len(action_nums))
        plt.plot(steps, action_nums, label=f"Episode {ep_index}")

    plt.xlabel("Step", fontsize=20)
    plt.ylabel("Action index (i*1000 + j)", fontsize=20)
    # plt.title("Chosen Actions Over Steps", fontsize=25)
    plt.legend()

    if save_path:
        plt.savefig(save_path)

    if csv_path:
        directory = os.path.dirname(csv_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Episode", "Step", "Action_i", "Action_j", "EncodedAction"])
            for ep_i, actions in enumerate(episode_actions_history, start=1):
                for step_i, (i, j) in enumerate(actions, start=1):
                    encoded = i * 1000 + j
                    writer.writerow([ep_i, step_i, i, j, encoded])

    if show:
        plt.show()
    else:
        plt.close()


def save_action_history(episode_actions_history, save_path="action_history.csv"):
    """
    Saves the chosen actions (pairs) for each episode into a CSV.
    Each row: Episode, Step, i, j
    """
    directory = os.path.dirname(save_path)
    if directory and not os.path.exists(directory):
        os.makedirs(directory)

    with open(save_path, mode='w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["Episode", "Step", "Action_i", "Action_j"])
        for ep_index, actions in enumerate(episode_actions_history):
            for step_index, (i, j) in enumerate(actions):
                writer.writerow([ep_index+1, step_index+1, i, j])

    print(f"[INFO] Action history saved to {save_path}")

def plot_blocks_and_dof_dual_axis(blocks_history, dof_history, target_dof=3,
                                  show=True, save_path=None, csv_path=None):
    import matplotlib.pyplot as plt
    import os
    import csv

    episodes = list(range(1, len(blocks_history) + 1))

    # Création de la figure et des axes
    fig, ax1 = plt.subplots(figsize=(15, 8))
    ax2 = ax1.twinx()

    # Tracé du nombre de blocks sur l'axe de gauche
    ax1.plot(episodes, blocks_history,
             marker='o', linewidth=2,
             label='Interlocking Blocks')
    ax1.set_xlabel('Episode')
    ax1.set_ylabel('Interlocking Blocks')
    ax1.grid(True, linestyle='--', alpha=0.7)

    # Tracé du DOF final sur l'axe de droite
    ax2.plot(episodes, dof_history,
             marker='s', linewidth=2,
             color='tab:red', label='Final DOF')
    ax2.set_ylabel('Final DOF')

    # Ligne cible DOF (optionnelle)
    ax2.axhline(y=target_dof, linestyle='--', linewidth=1.5,
                color='tab:red', alpha=0.7, label=f'Target DOF = {target_dof}')

    # Légende commune
    lines_1, labels_1 = ax1.get_legend_handles_labels()
    lines_2, labels_2 = ax2.get_legend_handles_labels()
    fig.legend(lines_1 + lines_2, labels_1 + labels_2, loc='upper right')

    # plt.title('Interlocking Blocks (gauche) vs Final DOF (droite) par Épisode')

    # Sauvegarde CSV
    if csv_path:
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Episode', 'Interlocking Blocks', 'Final DOF'])
            for ep, blk, df in zip(episodes, blocks_history, dof_history):
                writer.writerow([ep, blk, df])

    # Sauvegarde PNG
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path)

    if show:
        plt.show()
    else:
        plt.close()

# def plot_blocks_and_dof_per_episode(blocks_history, dof_history, target_dof=3,
#                                     show=True, save_path=None, csv_path=None):
#
#     episodes = list(range(1, len(blocks_history) + 1))
#
#     # Figure : blocs & DOF par épisode
#     plt.figure(figsize=(15, 8))
#     plt.plot(episodes, blocks_history, marker='o', linewidth=2, label='Interlocking Blocks')
#     plt.plot(episodes, dof_history, marker='s', linewidth=2, label='Final DOF')
#     plt.axhline(y=target_dof, linestyle='--', linewidth=1.5,
#                 label=f'Target DOF = {target_dof}')
#     plt.xlabel('Episode')
#     plt.ylabel('Valeur')
#     plt.title('Interlocking Blocks et Final DOF par Épisode')
#     plt.grid(True, linestyle='--', alpha=0.7)
#     plt.legend()
#
#     if save_path:
#         os.makedirs(os.path.dirname(save_path), exist_ok=True)
#         plt.savefig(save_path)
#     if csv_path:
#         os.makedirs(os.path.dirname(csv_path), exist_ok=True)
#         with open(csv_path, 'w', newline='') as f:
#             writer = csv.writer(f)
#             writer.writerow(['Episode', 'Interlocking Blocks', 'Final DOF'])
#             for ep, blk, df in zip(episodes, blocks_history, dof_history):
#                 writer.writerow([ep, blk, df])
#
#     if show:
#         plt.show()
#     else:
#         plt.close()
