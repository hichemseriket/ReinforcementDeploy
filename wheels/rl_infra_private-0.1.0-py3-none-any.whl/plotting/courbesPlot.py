import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("TkAgg")

# 1) Cumulative Reward & Steps
def plot_cumulative_reward_and_steps(csv_path,
                                     fig_size=(12, 7),
                                     dpi=150,
                                     axis_fontsize=16,
                                     tick_fontsize=14,
                                     legend_fontsize=10,
                                     line_width=1.5):
    df = pd.read_csv(csv_path)
    # Cumulative Reward
    fig, ax = plt.subplots(figsize=fig_size, dpi=dpi)
    ax.plot(df['Episode'], df['Reward'],
            linewidth=line_width, color='tab:blue', label='Cumulative Reward')
    ax.set_xlabel('Episode', fontsize=axis_fontsize)
    ax.set_ylabel('Reward', fontsize=axis_fontsize)
    ax.tick_params(labelsize=tick_fontsize)
    ax.grid(True, linestyle='--', linewidth=0.5)
    ax.legend(loc='lower right', fontsize=legend_fontsize)
    fig.tight_layout()

    # Steps per Episode
    fig, ax = plt.subplots(figsize=fig_size, dpi=dpi)
    ax.plot(df['Episode'], df['Steps'],
            linewidth=line_width, color='tab:orange', label='Steps per Episode')
    ax.set_xlabel('Episode', fontsize=axis_fontsize)
    ax.set_ylabel('Steps', fontsize=axis_fontsize)
    ax.tick_params(labelsize=tick_fontsize)
    ax.grid(True, linestyle='--', linewidth=0.5)
    ax.legend(loc='upper right', fontsize=legend_fontsize)
    fig.tight_layout()


# 2) Time History
def plot_time_history(csv_path,
                      fig_size=(12, 7),
                      dpi=150,
                      axis_fontsize=16,
                      tick_fontsize=14,
                      legend_fontsize=10,
                      line_width=1.5):
    df = pd.read_csv(csv_path)
    fig, ax = plt.subplots(figsize=fig_size, dpi=dpi)
    ax.plot(df['Episode'], df['Time_s'],
            linewidth=line_width, color='tab:purple', label='Time per Episode')
    ax.set_xlabel('Episode', fontsize=axis_fontsize)
    ax.set_ylabel('Time (s)', fontsize=axis_fontsize)
    ax.tick_params(labelsize=tick_fontsize)
    ax.grid(True, linestyle='--', linewidth=0.5)
    ax.legend(loc='upper right', fontsize=legend_fontsize)
    fig.tight_layout()


# 3) Blocks & DOF
def plot_blocks_and_dof(csv_path,
                        fig_size=(12, 7),
                        dpi=150,
                        axis_fontsize=16,
                        tick_fontsize=14,
                        legend_fontsize=10,
                        fill_zero_with=3,
                        target_dof=3.0,
                        blocks_top_margin=1.0,
                        line_width=1.5):
    df = pd.read_csv(csv_path)
    df['Final DOF'] = df['Final DOF'].replace(0, fill_zero_with)
    y1_max = df['Interlocking Blocks'].max()

    fig, ax1 = plt.subplots(figsize=fig_size, dpi=dpi)
    ax1.plot(df['Episode'], df['Interlocking Blocks'],
             linewidth=line_width, color='deepskyblue', label='Interlocking Blocks')
    ax1.set_xlabel('Episode', fontsize=axis_fontsize)
    ax1.set_ylabel('Number of Blocks', fontsize=axis_fontsize, color='deepskyblue')
    ax1.tick_params(labelsize=tick_fontsize, axis='y', labelcolor='deepskyblue')
    ax1.set_ylim(0, y1_max + blocks_top_margin)

    ax2 = ax1.twinx()
    ax2.plot(df['Episode'], df['Final DOF'],
             linewidth=line_width, color='red', label='Final DOF')
    ax2.set_ylabel('Final DOF', fontsize=axis_fontsize, color='red')
    ax2.tick_params(labelsize=tick_fontsize, axis='y', labelcolor='red')
    ax2.set_ylim(0, 4)
    ax2.set_yticks([0, 1, 2, 3, 4])
    ax2.axhline(target_dof, color='gray', linestyle='--',
                linewidth=line_width, label=f'Target DOF = {target_dof}')

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc='lower left', fontsize=legend_fontsize)

    ax1.grid(True, linestyle='--', linewidth=0.5)
    fig.tight_layout()


# 4) DOF every-n & Highlight All
def plot_dof_every_n_and_all(csv_path,
                             n=50,
                             fig_size=(12, 7),
                             dpi=150,
                             axis_fontsize=16,
                             tick_fontsize=14,
                             legend_fontsize=10,
                             line_width=1.5,
                             bg_color='black',
                             bg_alpha=0.1,
                             target_dof=3.0):
    df = pd.read_csv(csv_path)
    max_ep = df['Episode'].max()
    eps_n = [ep for ep in range(n, max_ep + 1, n) if ep in df['Episode'].unique()]
    cmap = plt.cm.tab10
    colors = {ep: cmap(i % 10) for i, ep in enumerate(eps_n)}

    # every-n plot
    fig1, ax1 = plt.subplots(figsize=fig_size, dpi=dpi)
    for ep in eps_n:
        d = df[df['Episode'] == ep]
        ax1.plot(d['Step'], d['DOF'],
                 color=colors[ep], linewidth=line_width, label=f'Episode {ep}')
    ax1.axhline(target_dof, color='red', linestyle='--',
                linewidth=line_width, label=f'Target DOF = {target_dof}')
    ax1.set_xlabel('Step', fontsize=axis_fontsize)
    ax1.set_ylabel('DOF', fontsize=axis_fontsize)
    ax1.tick_params(labelsize=tick_fontsize)
    ax1.grid(True, linestyle='--', linewidth=0.5)
    ax1.legend(loc='upper right', fontsize=legend_fontsize)
    fig1.tight_layout()

    # all episodes highlight
    fig2, ax2 = plt.subplots(figsize=fig_size, dpi=dpi)
    for ep in sorted(df['Episode'].unique()):
        d = df[df['Episode'] == ep]
        if ep in eps_n:
            ax2.plot(d['Step'], d['DOF'],
                     color=colors[ep], linewidth=line_width, label=f'Episode {ep}')
        else:
            ax2.plot(d['Step'], d['DOF'],
                     color=bg_color, linewidth=0.5, alpha=bg_alpha)
    ax2.axhline(target_dof, color='red', linestyle='--',
                linewidth=line_width, label=f'Target DOF = {target_dof}')
    ax2.set_xlabel('Step', fontsize=axis_fontsize)
    ax2.set_ylabel('DOF', fontsize=axis_fontsize)
    ax2.tick_params(labelsize=tick_fontsize)
    ax2.grid(True, linestyle='--', linewidth=0.5)
    fig2.tight_layout()


if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.abspath(__file__))
    src_dir = os.path.abspath(os.path.join(base_dir, os.pardir))
    root = os.path.join(src_dir,
                        'results',
                        'Arch17Avril100ep160VperPc10ksteps',
                        'EpisodePlots',
                        'final_plots')

    # 1) reward_and_steps.csv
    plot_cumulative_reward_and_steps(os.path.join(root, 'reward_and_steps', 'reward_and_steps.csv'))

    # 2) time_history.csv
    plot_time_history(os.path.join(root, 'time_history', 'time_history.csv'))

    # 3) blocks_and_dof_dual.csv
    plot_blocks_and_dof(os.path.join(root, 'blocks_and_dof', 'blocks_and_dof_dual.csv'))

    # 4) dof_evolution.csv (every‑n + all)
    plot_dof_every_n_and_all(os.path.join(root, 'dof_evolution_all', 'dof_evolution.csv'), n=50)

    # Show all figures at once
    plt.show()
