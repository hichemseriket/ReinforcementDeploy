import pandas as pd
import matplotlib.pyplot as plt
import matplotlib

matplotlib.use("TkAgg")


def plot_cumulative_reward(csv_path,
                           x_margin: float = 0.02,
                           y_margin: float = 0.05):
    """
    Plots Cumulative Reward per Episode as a standalone figure,
    with legend in the bottom‑right corner.
    """
    # Load data
    df = pd.read_csv(csv_path)

    # Create figure + axis
    fig, ax = plt.subplots(figsize=(10, 6), dpi=150)

    # Plot cumulative reward
    ax.plot(df['Episode'],
            df['Reward'],
            marker='o',
            linestyle='-',
            color='tab:blue',
            label='Cumulative Reward')

    # Labels
    ax.set_xlabel('Episode')
    ax.set_ylabel('Reward')

    # Margins & grid
    ax.margins(x=x_margin, y=y_margin)
    ax.grid(which='both', linestyle='--', linewidth=0.5)

    # Legend bottom‑right
    ax.legend(loc='lower right')

    fig.tight_layout()
    plt.show()


def plot_steps_per_episode(csv_path,
                           x_margin: float = 0.02,
                           y_margin: float = 0.05):
    """
    Plots Steps per Episode as a standalone figure.
    """
    # Load data
    df = pd.read_csv(csv_path)

    # Create figure + axis
    fig, ax = plt.subplots(figsize=(10, 6), dpi=150)

    # Plot steps
    ax.plot(df['Episode'],
            df['Steps'],
            marker='o',
            linestyle='-',
            color='tab:orange',
            label='Steps per Episode')

    # Labels
    ax.set_xlabel('Episode')
    ax.set_ylabel('Steps')

    # Margins & grid
    ax.margins(x=x_margin, y=y_margin)
    ax.grid(which='both', linestyle='--', linewidth=0.5)

    # Default legend location (you can change it if needed)
    ax.legend(loc='upper right')

    fig.tight_layout()
    plt.show()


if __name__ == '__main__':
    # Replace with your actual CSV path
    csv_path = r'C:\Users\serik\Downloads\Cube17Avril100episodes10Ksteps90VperPc\Cube17Avril500episodes10Ksteps90VperPc\EpisodePlots\final_plots\reward_and_steps\reward_and_steps.csv'

    plot_cumulative_reward(csv_path)
    plot_steps_per_episode(csv_path)

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib

matplotlib.use("TkAgg")


def plot_time_history(csv_path,
                      x_margin: float = 0.02,
                      y_margin: float = 0.05):
    """
    Plots Time per Episode using the TkAgg backend,
    at the same 10×6 inch, 150 DPI size as the previous figure.
    """
    # Load data
    df = pd.read_csv(csv_path)

    # Create figure + axis
    fig, ax = plt.subplots(figsize=(10, 6), dpi=150)

    # Plot using the correct column name
    ax.plot(df['Episode'],
            df['Time_s'],
            marker='o',
            linestyle='-',
            color='tab:purple',
            label='Time per Episode')

    # Labels
    ax.set_xlabel('Episode')
    ax.set_ylabel('Time (s)')

    # Add margins
    ax.margins(x=x_margin, y=y_margin)

    # Grid and legend
    ax.grid(which='both', linestyle='--', linewidth=0.5)
    ax.legend(loc='upper right')

    fig.tight_layout()
    plt.show()


if __name__ == '__main__':
    csv_path = r'C:\Users\serik\Downloads\Cube17Avril100episodes10Ksteps90VperPc\Cube17Avril500episodes10Ksteps90VperPc\EpisodePlots\final_plots\time_history\time_history.csv'
    plot_time_history(csv_path)
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("TkAgg")

def plot_blocks_and_dof(csv_path,
                        same_scale: bool = False,
                        dof_ylim: tuple = (0, 4),
                        target_dof: float = 3.0,
                        fill_zero_with: int = 3,
                        x_margin: float = 0.02,
                        blocks_top_margin: float = 1.0):
    """
    Plots Interlocking Blocks on left y-axis and Final DOF on right y-axis,
    replaces any Final DOF == 0 with `fill_zero_with`, draws a dashed
    line at target_dof, and adds absolute top margin to the blocks axis.

    Parameters:
      csv_path           : path to your CSV file
      same_scale         : if True, use the same y-limits for both axes
      dof_ylim           : y-limits for DOF axis if same_scale is False (default 0–4)
      target_dof         : horizontal target line for DOF (default 3.0)
      fill_zero_with     : value to replace any Final DOF == 0 (default 3)
      x_margin           : relative margin on x-axis (default 2%)
      blocks_top_margin  : absolute top margin in blocks units (default 1.0)
    """
    # Load data
    df = pd.read_csv(csv_path)

    # Replace zeros in Final DOF
    df['Final DOF'] = df['Final DOF'].replace(0, fill_zero_with)

    # Determine y-max for blocks
    y1_max = df['Interlocking Blocks'].max()

    # Create figure + first axis
    fig, ax1 = plt.subplots(figsize=(10, 6), dpi=150)

    # Plot Interlocking Blocks
    ax1.plot(df['Episode'],
             df['Interlocking Blocks'],
             marker='o', linestyle='-',
             label='Interlocking Blocks',
             color='deepskyblue')
    ax1.set_xlabel('Episode')
    ax1.set_ylabel('Number of Blocks', color='deepskyblue')
    ax1.tick_params(axis='y', labelcolor='deepskyblue')
    ax1.set_ylim(0, y1_max + blocks_top_margin)

    # Plot Final DOF on twin axis
    ax2 = ax1.twinx()
    ax2.plot(df['Episode'],
             df['Final DOF'],
             marker='s', linestyle='-',
             label='Final DOF',
             color='red')
    ax2.set_ylabel('Final DOF', color='red')
    ax2.tick_params(axis='y', labelcolor='red')

    # Apply scaling choice
    if same_scale:
        ax2.set_ylim(ax1.get_ylim())
    else:
        ax2.set_ylim(*dof_ylim)
    # Tick marks 0,1,2,3,4 on DOF axis
    ax2.set_yticks(list(range(int(dof_ylim[0]), int(dof_ylim[1]) + 1)))

    # Add dashed line for target DOF
    ax2.axhline(y=target_dof,
                color='gray',
                linestyle='--',
                label=f'Target DOF = {target_dof}')

    # Add horizontal margin on x-axis
    ax1.margins(x=x_margin)

    # Combine legends and place at bottom-left
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc='lower left')

    # Grid and layout
    ax1.grid(which='both', linestyle='--', linewidth=0.5)
    fig.tight_layout()
    plt.show()


if __name__ == '__main__':
    # csv_path = r'C:\Users\serik\Downloads\Cube17Avril100episodes10Ksteps90VperPc\Cube17Avril500episodes10Ksteps90VperPc\EpisodePlots\final_plots\blocks_and_dof\blocks_and_dof.csv'
    csv_path = r'C:\Users\serik\Downloads\Cube17Avril100episodes10Ksteps90VperPc\Cube17Avril500episodes10Ksteps90VperPc\EpisodePlots\final_plots\blocks_and_dof\blocks_and_dof.csv'
    plot_blocks_and_dof(
        csv_path,
        same_scale=False,
        dof_ylim=(0, 4),
        target_dof=3.0,
        fill_zero_with=3,
        x_margin=0.02,
        blocks_top_margin=1.0
    )
