import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib
matplotlib.use('TkAgg')

# # Données fournies
# poutre
episode_data = [(100, 27, 26), (99, 16, 16), (98, 23, 5), (97, 48, 45), (96, 20, 7), (95, 136, 93),
                     (94, 130, 31), (93, 8, 98), (92, 19, 9), (91, 21, 8), (90, 24, 29), (89, 18, 17), (88, 19, 41),
                     (87, 128, 31), (86, 132, 65), (85, 136, 92), (84, 40, 26), (83, 19, 51), (82, 20, 8), (81, 12, 102),
                     (80, 16, 45), (79, 10, 93), (78, 21, 50), (77, 16, 11), (76, 18, 12), (75, 16, 6), (74, 18, 8),
                     (73, 47, 19), (72, 22, 48), (71, 17, 3), (70, 17, 5), (69, 26, 54), (68, 16, 4), (67, 21, 3),
                     (66, 28, 20), (65, 131, 29), (64, 3, 123), (63, 125, 50), (62, 29, 46), (61, 22, 56), (60, 17, 12),
                     (59, 18, 6), (58, 110, 25), (57, 136, 106), (56, 135, 31), (55, 39, 59), (54, 19, 101), (53, 19, 61),
                     (52, 14, 63), (51, 16, 69), (50, 20, 12), (49, 20, 9), (48, 17, 81), (47, 19, 5), (46, 18, 10),
                     (45, 85, 22), (44, 148, 67), (43, 135, 56), (42, 15, 39), (41, 10, 107), (40, 20, 47), (39, 28, 8),
                     (38, 47, 27), (37, 18, 5), (36, 17, 6), (35, 20, 5), (34, 20, 6), (33, 22, 6), (32, 86, 39),
                     (31, 144, 21), (30, 140, 34), (29, 137, 58), (28, 36, 7), (27, 3, 123), (26, 137, 31), (25, 14, 37),
                     (24, 137, 54), (23, 14, 78), (22, 31, 52), (21, 19, 75), (20, 36, 43), (19, 19, 5), (18, 20, 6),
                     (17, 18, 3), (16, 18, 3), (15, 67, 10), (14, 143, 40), (13, 8, 87), (12, 25, 60), (11, 39, 75),
                     (10, 40, 56), (9, 132, 45), (8, 19, 52), (7, 11, 83), (6, 44, 43), (5, 21, 7), (4, 12, 77),
                     (3, 18, 5), (2, 17, 4), (1, 20, 4)]

# cube data
episode_data = [
    (1, 11, 2), (2, 12, 2), (3, 37, 2), (4, 47, 3), (5, 14, 3), (6, 13, 3), (7, 18, 3), (8, 11, 3),
    (9, 9, 3), (10, 8, 2), (11, 13, 3), (12, 11, 3), (13, 11, 3), (14, 7, 2), (15, 10, 3), (16, 9, 3),
    (17, 8, 3), (18, 12, 2), (19, 9, 3), (20, 11, 2), (21, 12, 2), (22, 19, 3), (23, 19, 3), (24, 12, 3),
    (25, 12, 1), (26, 11, 3), (27, 11, 3), (28, 11, 1), (29, 10, 2), (30, 10, 2), (31, 14, 3), (32, 12, 3),
    (33, 6, 9), (34, 9, 3), (35, 31, 2), (36, 6, 1), (37, 10, 3), (38, 9, 2), (39, 10, 3), (40, 16, 3),
    (41, 7, 3), (42, 9, 2), (43, 15, 3), (44, 10, 2), (45, 9, 3), (46, 11, 3), (47, 6, 3), (48, 9, 3),
    (49, 13, 3), (50, 8, 3), (51, 9, 3), (52, 8, 3), (53, 9, 3), (54, 15, 3), (55, 9, 3), (56, 25, 3),
    (57, 13, 2), (58, 9, 2), (59, 11, 3), (60, 10, 2), (61, 9, 1), (62, 20, 2), (63, 6, 2), (64, 9, 3),
    (65, 20, 3), (66, 13, 2), (67, 12, 3), (68, 11, 3), (69, 11, 2), (70, 10, 2), (71, 7, 3), (72, 7, 3),
    (73, 9, 2), (74, 6, 3), (75, 14, 3), (76, 8, 2), (77, 15, 3), (78, 5, 2), (79, 8, 3), (80, 9, 1),
    (81, 9, 3), (82, 7, 3), (83, 10, 3), (84, 10, 2), (85, 11, 1), (86, 5, 2), (87, 5, 3), (88, 7, 2),
    (89, 6, 3), (90, 8, 3), (91, 8, 3), (92, 7, 2), (93, 9, 2), (94, 11, 3), (95, 11, 3), (96, 8, 2),
    (97, 9, 3), (98, 11, 3), (99, 10, 3), (100, 8, 3)
]

df = pd.DataFrame(episode_data, columns=["Episode", "Interlocking Blocks", "DOF"])

# Figure 1 : Une seule figure avec les deux séries et une ligne pour le DOF target
plt.figure(figsize=(15, 8))

# Tracer les données
plt.plot(df['Episode'], df['Interlocking Blocks'], color='tab:blue', marker='o', markersize=4,
        linewidth=2, label='Interlocking Blocks')
plt.plot(df['Episode'], df['DOF'], color='tab:red', marker='s', markersize=4,
        linewidth=2, label='Final DOF')

# Ajouter une ligne horizontale pour le DOF target à 3
plt.axhline(y=3, color='red', linestyle='--', alpha=0.7, label='DOF Target (3)')

# Configurer les axes et les légendes
plt.xlabel('Episode', fontsize=12)
plt.ylabel('Value', fontsize=12)
# plt.title('Interlocking Blocks and Final DOF per Episode', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.7)
plt.legend(loc='best', fontsize=10)

# S'assurer que les ticks de l'axe X sont visibles
plt.xticks(range(0, 101, 10))

# Ajuster l'espacement
plt.tight_layout()

# Figure 2 : Histogramme des DOF
plt.figure(figsize=(10, 6))
sns.countplot(x='DOF', data=df, palette='Blues')
plt.title('Distribution of Final DOF', fontsize=14)
plt.xlabel('Final DOF', fontsize=12)
plt.ylabel('Number of Episodes', fontsize=12)
plt.grid(True, axis='y', linestyle='--', alpha=0.7)

# Figure 3 : Histogramme des Interlocking Blocks
plt.figure(figsize=(10, 6))
sns.histplot(df['Interlocking Blocks'], bins=15, kde=True, color='green')
plt.title('Distribution of Number of Interlocking Blocks', fontsize=14)
plt.xlabel('Interlocking Blocks in Solution', fontsize=12)
plt.ylabel('Number of Episodes', fontsize=12)
plt.grid(True, axis='y', linestyle='--', alpha=0.7)

plt.tight_layout()
plt.show()


#
# # recuperation des données dimages
# import re
#
# # Liste des fichiers
# filenames = [
#     "episode_100_state_27pv_26dof.png",
#     "episode_99_state_16pv_16dof.png",
#     "episode_98_state_23pv_5dof.png",
#     "episode_97_state_48pv_45dof.png",
#     "episode_96_state_20pv_7dof.png",
#     "episode_95_state_136pv_93dof.png",
#     "episode_94_state_130pv_31dof.png",
#     "episode_93_state_8pv_98dof.png",
#     "episode_92_state_19pv_9dof.png",
#     "episode_91_state_21pv_8dof.png",
#     "episode_90_state_24pv_29dof.png",
#     "episode_89_state_18pv_17dof.png",
#     "episode_88_state_19pv_41dof.png",
#     "episode_87_state_128pv_31dof.png",
#     "episode_86_state_132pv_65dof.png",
#     "episode_85_state_136pv_92dof.png",
#     "episode_84_state_40pv_26dof.png",
#     "episode_83_state_19pv_51dof.png",
#     "episode_82_state_20pv_8dof.png",
#     "episode_81_state_12pv_102dof.png",
#     "episode_80_state_16pv_45dof.png",
#     "episode_79_state_10pv_93dof.png",
#     "episode_78_state_21pv_50dof.png",
#     "episode_77_state_16pv_11dof.png",
#     "episode_76_state_18pv_12dof.png",
#     "episode_75_state_16pv_6dof.png",
#     "episode_74_state_18pv_8dof.png",
#     "episode_73_state_47pv_19dof.png",
#     "episode_72_state_22pv_48dof.png",
#     "episode_71_state_17pv_3dof.png",
#     "episode_70_state_17pv_5dof.png",
#     "episode_69_state_26pv_54dof.png",
#     "episode_68_state_16pv_4dof.png",
#     "episode_67_state_21pv_3dof.png",
#     "episode_66_state_28pv_20dof.png",
#     "episode_65_state_131pv_29dof.png",
#     "episode_64_state_3pv_123dof.png",
#     "episode_63_state_125pv_50dof.png",
#     "episode_62_state_29pv_46dof.png",
#     "episode_61_state_22pv_56dof.png",
#     "episode_60_state_17pv_12dof.png",
#     "episode_59_state_18pv_6dof.png",
#     "episode_58_state_110pv_25dof.png",
#     "episode_57_state_136pv_106dof.png",
#     "episode_56_state_135pv_31dof.png",
#     "episode_55_state_39pv_59dof.png",
#     "episode_54_state_19pv_101dof.png",
#     "episode_53_state_19pv_61dof.png",
#     "episode_52_state_14pv_63dof.png",
#     "episode_51_state_16pv_69dof.png",
#     "episode_50_state_20pv_12dof.png",
#     "episode_49_state_20pv_9dof.png",
#     "episode_48_state_17pv_81dof.png",
#     "episode_47_state_19pv_5dof.png",
#     "episode_46_state_18pv_10dof.png",
#     "episode_45_state_85pv_22dof.png",
#     "episode_44_state_148pv_67dof.png",
#     "episode_43_state_135pv_56dof.png",
#     "episode_42_state_15pv_39dof.png",
#     "episode_41_state_10pv_107dof.png",
#     "episode_40_state_20pv_47dof.png",
#     "episode_39_state_28pv_8dof.png",
#     "episode_38_state_47pv_27dof.png",
#     "episode_37_state_18pv_5dof.png",
#     "episode_36_state_17pv_6dof.png",
#     "episode_35_state_20pv_5dof.png",
#     "episode_34_state_20pv_6dof.png",
#     "episode_33_state_22pv_6dof.png",
#     "episode_32_state_86pv_39dof.png",
#     "episode_31_state_144pv_21dof.png",
#     "episode_30_state_140pv_34dof.png",
#     "episode_29_state_137pv_58dof.png",
#     "episode_28_state_36pv_7dof.png",
#     "episode_27_state_3pv_123dof.png",
#     "episode_26_state_137pv_31dof.png",
#     "episode_25_state_14pv_37dof.png",
#     "episode_24_state_137pv_54dof.png",
#     "episode_23_state_14pv_78dof.png",
#     "episode_22_state_31pv_52dof.png",
#     "episode_21_state_19pv_75dof.png",
#     "episode_20_state_36pv_43dof.png",
#     "episode_19_state_19pv_5dof.png",
#     "episode_18_state_20pv_6dof.png",
#     "episode_17_state_18pv_3dof.png",
#     "episode_16_state_18pv_3dof.png",
#     "episode_15_state_67pv_10dof.png",
#     "episode_14_state_143pv_40dof.png",
#     "episode_13_state_8pv_87dof.png",
#     "episode_12_state_25pv_60dof.png",
#     "episode_11_state_39pv_75dof.png",
#     "episode_10_state_40pv_56dof.png",
#     "episode_9_state_132pv_45dof.png",
#     "episode_8_state_19pv_52dof.png",
#     "episode_7_state_11pv_83dof.png",
#     "episode_6_state_44pv_43dof.png",
#     "episode_5_state_21pv_7dof.png",
#     "episode_4_state_12pv_77dof.png",
#     "episode_3_state_18pv_5dof.png",
#     "episode_2_state_17pv_4dof.png",
#     "episode_1_state_20pv_4dof.png"
# ]
#
# # Expression régulière pour extraire les valeurs
# pattern = r"episode_(\d+)_state_(\d+)pv_(\d+)dof\.png"
#
# # Création de la nouvelle liste de tuples
# data_tuples = []
# for filename in filenames:
#     match = re.search(pattern, filename)
#     if match:
#         episode = int(match.group(1))
#         pv = int(match.group(2))
#         dof = int(match.group(3))
#         data_tuples.append((episode, pv, dof))
#     else:
#         print(f"Le fichier {filename} ne correspond pas au format attendu.")
#
# # Affichage de la liste des tuples
# print(data_tuples)
