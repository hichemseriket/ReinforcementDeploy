import os
import glob
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("TkAgg")

# --- 1) Cumulative Reward & Steps ---
def plot_cumulative_reward_and_steps(csv_path, output_dir,
                                     fig_size=(12, 7), dpi=150,
                                     axis_fontsize=16, tick_fontsize=14,
                                     legend_fontsize=10, line_width=1.5):
    df = pd.read_csv(csv_path)

    # Cumulative Reward
    fig, ax = plt.subplots(figsize=fig_size, dpi=dpi)
    ax.plot(df['Episode'], df['Reward'],
            linewidth=line_width, color='tab:blue', label='Cumulative Reward')
    ax.set_xlabel('Episode', fontsize=axis_fontsize)
    ax.set_ylabel('Reward', fontsize=axis_fontsize)
    ax.tick_params(labelsize=tick_fontsize)
    ax.grid(True, linestyle='--', linewidth=0.5)
    ax.legend(loc='lower right', fontsize=legend_fontsize)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, 'cumulative_reward.png'))

    # Steps per Episode
    fig, ax = plt.subplots(figsize=fig_size, dpi=dpi)
    ax.plot(df['Episode'], df['Steps'],
            linewidth=line_width, color='tab:orange', label='Step per Episode')
    ax.set_xlabel('Episode', fontsize=axis_fontsize)
    ax.set_ylabel('Step', fontsize=axis_fontsize)
    ax.tick_params(labelsize=tick_fontsize)
    ax.grid(True, linestyle='--', linewidth=0.5)
    ax.legend(loc='upper right', fontsize=legend_fontsize)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, 'steps_per_episode.png'))


# --- 2) Time History ---
def plot_time_history(csv_path, output_dir,
                      fig_size=(12, 7), dpi=150,
                      axis_fontsize=16, tick_fontsize=14,
                      legend_fontsize=10, line_width=1.5):
    df = pd.read_csv(csv_path)
    fig, ax = plt.subplots(figsize=fig_size, dpi=dpi)
    ax.plot(df['Episode'], df['Time_s'],
            linewidth=line_width, color='tab:purple', label='Time per Episode')
    ax.set_xlabel('Episode', fontsize=axis_fontsize)
    ax.set_ylabel('Time (s)', fontsize=axis_fontsize)
    ax.tick_params(labelsize=tick_fontsize)
    ax.grid(True, linestyle='--', linewidth=0.5)
    ax.legend(loc='upper right', fontsize=legend_fontsize)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, 'time_history.png'))


# --- 3) Blocks & DOF ---
def plot_blocks_and_dof(csv_path, output_dir,
                        fig_size=(12, 7), dpi=150,
                        axis_fontsize=16, tick_fontsize=14,
                        legend_fontsize=10, fill_zero_with=3,
                        target_dof=3.0, blocks_top_margin=1.0,
                        line_width=1.5):
    df = pd.read_csv(csv_path)
    df['Final DOF'] = df['Final DOF'].replace(0, fill_zero_with)
    y1_max = df['Interlocking Blocks'].max()

    fig, ax1 = plt.subplots(figsize=fig_size, dpi=dpi)
    ax1.plot(df['Episode'], df['Interlocking Blocks'],
             linewidth=line_width, color='deepskyblue', label='Blocks')
    ax1.set_xlabel('Episode', fontsize=axis_fontsize)
    ax1.set_ylabel('Number of Blocks',
                   fontsize=axis_fontsize, color='deepskyblue')
    ax1.tick_params(labelsize=tick_fontsize,
                    axis='y', labelcolor='deepskyblue')
    ax1.set_ylim(0, y1_max + blocks_top_margin)

    ax2 = ax1.twinx()
    ax2.plot(df['Episode'], df['Final DOF'],
             linewidth=line_width, color='red', label='Final DOF')
    ax2.set_ylabel('Final DOF', fontsize=axis_fontsize, color='red')
    ax2.tick_params(labelsize=tick_fontsize,
                    axis='y', labelcolor='red')
    ax2.set_ylim(0, 4)
    ax2.set_yticks([0, 1, 2, 3, 4])
    ax2.axhline(target_dof, color='gray', linestyle='--',
                linewidth=line_width, label=f'Target DOF = {target_dof}')

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc='lower left',
               fontsize=legend_fontsize)

    ax1.grid(True, linestyle='--', linewidth=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, 'blocks_and_dof.png'))


# --- 4) DOF every-n & Highlight All ---
def plot_dof_every_n_and_all(csv_path, output_dir,
                             n=50, fig_size=(12, 7), dpi=150,
                             axis_fontsize=16, tick_fontsize=14,
                             legend_fontsize=10, line_width=1.5,
                             bg_color='black', bg_alpha=0.1,
                             target_dof=3.0):
    df = pd.read_csv(csv_path)
    max_ep = df['Episode'].max()
    eps_n = [ep for ep in range(n, max_ep + 1, n)
             if ep in df['Episode'].unique()]
    cmap = plt.cm.tab10
    colors = {ep: cmap(i % 10) for i, ep in enumerate(eps_n)}

    # every-n plot
    fig1, ax1 = plt.subplots(figsize=fig_size, dpi=dpi)
    for ep in eps_n:
        d = df[df['Episode'] == ep]
        ax1.plot(d['Step'], d['DOF'],
                 color=colors[ep], linewidth=line_width,
                 label=f'Episode {ep}')
    ax1.axhline(target_dof, color='red', linestyle='--',
                linewidth=line_width, label=f'Target DOF = {target_dof}')
    ax1.set_xlabel('Step', fontsize=axis_fontsize)
    ax1.set_ylabel('DOF', fontsize=axis_fontsize)
    ax1.tick_params(labelsize=tick_fontsize)
    ax1.grid(True, linestyle='--', linewidth=0.5)
    ax1.legend(loc='upper right', fontsize=legend_fontsize)
    fig1.tight_layout()
    fig1.savefig(os.path.join(output_dir, f'dof_every_{n}.png'))

    # all episodes highlight
    fig2, ax2 = plt.subplots(figsize=fig_size, dpi=dpi)
    for ep in sorted(df['Episode'].unique()):
        d = df[df['Episode'] == ep]
        if ep in eps_n:
            ax2.plot(d['Step'], d['DOF'],
                     color=colors[ep], linewidth=line_width)
        else:
            ax2.plot(d['Step'], d['DOF'],
                     color=bg_color, linewidth=0.5, alpha=bg_alpha)
    ax2.axhline(target_dof, color='red', linestyle='--',
                linewidth=line_width)
    ax2.set_xlabel('Step', fontsize=axis_fontsize)
    ax2.set_ylabel('DOF', fontsize=axis_fontsize)
    ax2.tick_params(labelsize=tick_fontsize)
    ax2.grid(True, linestyle='--', linewidth=0.5)
    fig2.tight_layout()
    fig2.savefig(os.path.join(output_dir, f'dof_all_highlight_{n}.png'))

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.abspath(__file__))
    src_dir = os.path.abspath(os.path.join(base_dir, os.pardir))
    # results_dir = os.path.join(src_dir, 'results')
    # 3) descendre dans "main/results"
    results_dir = os.path.join(src_dir, 'main', 'results')

    # 4) (optionnel) vérifier que le dossier existe
    if not os.path.isdir(results_dir):
        raise FileNotFoundError(f"Le dossier results est introuvable : {results_dir}")

    # 5) utilisez results_dir pour lire/écrire vos fichiers
    print(f"Le répertoire des résultats est : {results_dir}")
    # List available experiment folders
    experiments = [d for d in os.listdir(results_dir)
                   if os.path.isdir(os.path.join(results_dir, d))]
    print("Available experiments:")
    for e in experiments:
        print(" ", e)

    # Prompt until a valid experiment is chosen
    while True:
        experiment = input("Enter experiment name (exactly as listed above): ").strip()
        if experiment in experiments:
            break
        print(f"❌ '{experiment}' not found. Please choose from the list above.")

    root = os.path.join(results_dir,
                        experiment,
                        'EpisodePlots',
                        'final_plots')

    # 1) reward & steps
    csv_reward_steps = os.path.join(root, 'reward_and_steps', 'reward_and_steps.csv')
    print("Loading:", csv_reward_steps)
    plot_cumulative_reward_and_steps(csv_reward_steps, output_dir=root)

    # 2) time history
    csv_time = os.path.join(root, 'time_history', 'time_history.csv')
    print("Loading:", csv_time)
    plot_time_history(csv_time, output_dir=root)

    # 3) blocks & dof (auto-detect .csv)
    blocks_dir = os.path.join(root, 'blocks_and_dof')
    csv_blocks = glob.glob(os.path.join(blocks_dir, '*.csv'))[0]
    print("Loading:", csv_blocks)
    plot_blocks_and_dof(csv_blocks, output_dir=root)

    # 4) dof evolution
    csv_dof = os.path.join(root, 'dof_evolution_all', 'dof_evolution.csv')
    print("Loading:", csv_dof)
    plot_dof_every_n_and_all(csv_dof, output_dir=root, n=10)

    # Show all at once
    plt.show()
