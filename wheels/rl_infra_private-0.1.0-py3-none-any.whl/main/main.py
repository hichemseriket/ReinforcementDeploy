from src.environment.VoxelEnvironment import VoxelEnvironment
from src.agent.QLearningAgent import QLearningAgent
from src.trainer.Trainer import Trainer
from src.plotting.plotting import *
import matplotlib
import os

matplotlib.use('Agg')

if __name__ == "__main__":
    # Initialisation de l'environnement
    env = VoxelEnvironment(max_polyvoxel_size=130)
    # env.load_points_from_csv("../dataInput/DATAPointsCSV/Toyota25x8x4Article.csv")
    # env.load_points_from_csv("../dataInput/DATAPointsCSV/NewSphereTrancheVide.csv")
    # env.load_points_from_csv("../dataInput/DATAPointsCSV/cube6x6x6.csv")
    env.load_points_from_csv("../dataInput/DATAPointsCSV/bunny0.3.csv")

    # Visualisation initiale de l'environnement
    plot_voxel_environment(env)

    # Configuration et initialisation de l'agent
    gx, gy, gz = env.grid_size_x, env.grid_size_y, env.grid_size_z
    agent = QLearningAgent(
        state_size=gx * gy * gz,
        action_size=gx * gy * gz,
        grid_size_x=gx,
        grid_size_y=gy,
        grid_size_z=gz,
        learning_rate=0.1,
        discount_rate=0.9,
        exploration_rate=0.9,
        exploration_decay=0.99,
        # model_save_path="models/qlearning_demo.pkl"
        # model_save_path="models/qlearning_demo_Plot.pkl"
        model_save_path="../../models/qlearning_Poutre.pkl"
        # model_save_path="models/qlearning_Bunny.pkl"
    )
    # Charger la Q-table existante (si le fichier existe)
    # agent.load_model("models/qlearning_demo.pkl")
    # agent.load_model("models/qlearning_Poutre.pkl")
    base_dir = '../results/SecondeBunny15Avril20kStep'
    output_csv_dir = os.path.join(base_dir, 'Distribution')
    disassembly_dir = os.path.join(base_dir, 'Dissasembly')
    episode_plots_dir = os.path.join(base_dir, 'EpisodePlots')
    # Création du Trainer
    trainer = Trainer(
        agent,
        env,
        episodes=1,
        max_steps=30000,
        checkpoint_interval=5,
        log_interval=5,
        output_csv_dir=output_csv_dir,
        # disassembly_dir='results/disassembly50x10x52',
        disassembly_dir=disassembly_dir,
        plot_every_episode=True,
        # episode_plots_dir='results/resPoutre50x10x5seconndRun2'
        episode_plots_dir=episode_plots_dir
    )
    trainer.train()
    for ep_idx, q_history in enumerate(trainer.episode_q_history):
        save_path = os.path.join(trainer.episode_plots_dir, f'episode_{ep_idx + 1}_q_vs_step.png')
        plot_q_value_vs_step(q_history, ep_idx + 1, show=False, save_path=save_path)
    # Sauvegarde des courbes globales
    plot_voxel_environment(env, show=False, save_path=os.path.join(trainer.episode_plots_dir, 'envFinal', 'final_voxel_env.png'))
    plot_training_history(agent, show=False, save_path=os.path.join(trainer.episode_plots_dir, 'trainingHistory', 'training_history.png'))
    plot_reward_and_steps(agent, show=False, save_path=os.path.join(trainer.episode_plots_dir, 'rewardAndStep', 'reward_and_steps.png'))
    plot_time_history(agent, show=False, save_path=os.path.join(trainer.episode_plots_dir, 'timeHistory', 'time_history.png'))
    # plot_dof_evolution_10Epiosdes(trainer.episode_dof_history,show=False, save_path=os.path.join(trainer.episode_plots_dir, 'timeHistory','dof_evolution_10epiosde.png'))
    plot_dof_evolution(trainer.episode_dof_history,show=False, save_path=os.path.join(trainer.episode_plots_dir, 'timeHistory','dof_evolution.png'))
    plot_action_indices(trainer.episode_actions_history,show=False, save_path=os.path.join(trainer.episode_plots_dir, 'timeHistory','action_indice_history.png'))
    save_action_history(trainer.episode_actions_history, save_path=os.path.join(trainer.episode_plots_dir, 'timeHistory','action_history.csv'))
    print("Entraînement terminé.")
