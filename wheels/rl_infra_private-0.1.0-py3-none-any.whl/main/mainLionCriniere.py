from src.environment.VoxelEnvironment import VoxelEnvironment
from src.agent.QLearningAgent import QLearningAgent
from src.trainer.Trainer import Trainer
import matplotlib
import os

matplotlib.use('Agg')  # Avoid interactive mode if running on a server

if __name__ == "__main__":
    # Initialize environment
    env = VoxelEnvironment(max_polyvoxel_size=460)
    env.load_points_from_csv("../../dataInput/DATAPointsCSV/lionDayl.csv")

    # Initialize agent
    gx, gy, gz = env.grid_size_x, env.grid_size_y, env.grid_size_z
    agent = QLearningAgent(
        state_size=gx * gy * gz,
        action_size=gx * gy * gz,
        grid_size_x=gx,
        grid_size_y=gy,
        grid_size_z=gz,
        learning_rate=0.1,
        discount_rate=0.9,
        exploration_rate=0.9,
        exploration_decay=0.99,
        model_save_path="../../models/qlearning_lion.pkl"
    )

    # Load model if it exists
    agent.load_model("models/qlearning_lion.pkl")
    base_dir = '../results/LionCriniere250KSteps5ep460VerPc'
    output_csv_dir = os.path.join(base_dir, 'Distribution')
    disassembly_dir = os.path.join(base_dir, 'Dissasembly')
    episode_plots_dir = os.path.join(base_dir, 'EpisodePlots')
    # Create trainer
    trainer = Trainer(
        agent,
        env,
        episodes=1,
        max_steps=250000,
        checkpoint_interval=5,
        log_interval=5,
        output_csv_dir=output_csv_dir,
        disassembly_dir=disassembly_dir,
        plot_every_episode=True,
        episode_plots_dir=episode_plots_dir
    )

    # Start training
    trainer.train()

    print("Training complete.")
