from src.environment.VoxelEnvironment import VoxelEnvironment
from src.agent.QLearningAgent import QLearningAgent
from src.trainer.Trainer import Trainer
from src.plotting.plotting import *
import matplotlib
import os

matplotlib.use('Agg')

if __name__ == "__main__":
    # Initialisation de l'environnement
    env = VoxelEnvironment(max_polyvoxel_size=400)
    # env.load_points_from_csv("../dataInput/DATAPointsCSV/Toyota25x8x4Article.csv")
    # env.load_points_from_csv("../dataInput/DATAPointsCSV/NewSphereTrancheVide.csv")
    # env.load_points_from_csv("../dataInput/DATAPointsCSV/cube6x6x6.csv")
    env.load_points_from_csv("../dataInput/DATAPointsCSV/bunny2500Point.csv")

    # Visualisation initiale de l'environnement
    plot_voxel_environment(env)

    # Configuration et initialisation de l'agent
    gx, gy, gz = env.grid_size_x, env.grid_size_y, env.grid_size_z
    agent = QLearningAgent(
        state_size=gx * gy * gz,
        action_size=gx * gy * gz,
        grid_size_x=gx,
        grid_size_y=gy,
        grid_size_z=gz,
        learning_rate=0.1,
        discount_rate=0.9,
        exploration_rate=0.9,
        exploration_decay=0.99,
        # model_save_path="models/qlearning_demo.pkl"
        # model_save_path="models/qlearning_demo_Plot.pkl"
        model_save_path="../../models/qlearning_Poutre.pkl"
        # model_save_path="models/qlearning_Bunny.pkl"
    )
    # Charger la Q-table existante (si le fichier existe)
    # agent.load_model("models/qlearning_demo.pkl")
    agent.load_model("models/qlearning_Poutre.pkl")
    base_dir = '../results/Bunny22Avril100kStep'
    output_csv_dir = os.path.join(base_dir, 'Distribution')
    disassembly_dir = os.path.join(base_dir, 'Dissasembly')
    episode_plots_dir = os.path.join(base_dir, 'EpisodePlots')
    # Création du Trainer
    trainer = Trainer(
        agent,
        env,
        episodes=1,
        max_steps=100000,
        checkpoint_interval=5,
        log_interval=5,
        output_csv_dir=output_csv_dir,
        # disassembly_dir='results/disassembly50x10x52',
        disassembly_dir=disassembly_dir,
        plot_every_episode=True,
        # episode_plots_dir='results/resPoutre50x10x5seconndRun2'
        episode_plots_dir=episode_plots_dir
    )
    trainer.train()
    print("Entraînement terminé.")
