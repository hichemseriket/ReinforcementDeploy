import os
import time
import random
import pickle
import numpy as np
import csv
import matplotlib.pyplot as plt
import pandas as pd

from src.agent.QLearningAgent import QLearningAgent
from src.environment.VoxelEnvironment import VoxelEnvironment
from src.plotting.plotting import (
    plot_reward_and_steps,
    plot_time_history,
    plot_voxel_environment
)

def run_inference(env, agent, max_steps=100000, target_dof=3):
    state = env.reset()
    rewards, step_times, blocks, dofs = [], [], [], []
    steps = 0
    t0_global = time.time()

    while steps < max_steps:
        _, adj = env.get_adjacent_entities()
        if not adj:
            break

        t0 = time.time()
        if random.random() < agent.exploration_rate:
            action = random.choice(adj)
        else:
            action = max(adj, key=lambda a: agent.get_q_value(state, a))

        state, r, done = env.step(action)
        step_times.append(time.time() - t0)
        rewards.append(r)
        blocks.append(len(env.polyvoxels))
        dofs.append(env.current_dof)

        steps += 1
        if done or env.current_dof <= target_dof:
            break

    return {
        'rewards': rewards,
        'step_times': step_times,
        'blocks': blocks,
        'dofs': dofs,
        'steps': steps,
        'total_time': time.time() - t0_global,
        'final_blocks': blocks[-1] if blocks else 0,
        'final_dof':    dofs[-1]   if dofs   else None
    }

# -- Configuration générale ---------------------------------------------
MODEL_PATH   = '../../models/qlearning_Poutre.pkl'
# MODEL_PATH   = 'models/qlearning_cube6x6x6.pkl'
# INPUT_CSV    = '../dataInput/DATAPointsCSV/cube6x6x6.csv'
INPUT_CSV    = '../dataInput/DATAPointsCSV/Bunny1000.csv'

RESULTS_DIR  = '../results/inference_bunny1000'
SEEDS        = [0, 1, 7, 42, 123]
# SEEDS        = [0, 1]
EPSILON      = 0.1
MAX_STEPS    = 50000
TARGET_DOF   = 3

os.makedirs(RESULTS_DIR, exist_ok=True)

# -- Préchargement de l'environnement et du Q-table -----------------------
env_template = VoxelEnvironment(max_polyvoxel_size=210)
env_template.load_points_from_csv(INPUT_CSV)
with open(MODEL_PATH, 'rb') as f:
    q_table_saved = pickle.load(f)

# -- Fichier de synthèse global ------------------------------------------
summary_fields = ['seed', 'steps', 'total_time', 'final_blocks', 'final_dof']
summary_csv    = os.path.join(RESULTS_DIR, 'inference_by_seed_lappin.csv')

with open(summary_csv, 'w', newline='') as f_csv:
    writer = csv.DictWriter(f_csv, fieldnames=summary_fields)
    writer.writeheader()

    for seed in SEEDS:
        # Réinitialisation
        random.seed(seed)
        np.random.seed(seed)

        # Clonage de l'environnement
        env = pickle.loads(pickle.dumps(env_template, -1))

        # Création de l'agent et chargement du Q-table
        agent = QLearningAgent(
            state_size=None, action_size=None,
            grid_size_x=env.grid_size_x,
            grid_size_y=env.grid_size_y,
            grid_size_z=env.grid_size_z,
            learning_rate=0.1, discount_rate=0.9,
            exploration_rate=EPSILON, exploration_decay=1.0
        )
        agent.q_table = q_table_saved

        # Exécution de l'inférence
        stats = run_inference(env, agent, max_steps=MAX_STEPS, target_dof=TARGET_DOF)
        stats['seed'] = seed

        # Enregistrement des métriques globales
        writer.writerow({k: stats[k] for k in summary_fields})

        # Création du dossier pour cette seed
        seed_dir = os.path.join(RESULTS_DIR, f'seed_{seed}')
        os.makedirs(seed_dir, exist_ok=True)

        # 1) CSV des polyvoxels pour Rhino
        env.write_polyvoxels_to_csv(seed, seed_dir)

        # 2) Reward & Steps (abscisse “Step”)
        class A: pass
        A.rewards_history = np.cumsum(stats['rewards']).tolist()
        A.steps_history   = list(range(1, len(stats['rewards']) + 1))
        plot_reward_and_steps(
            A, show=False,
            save_path=os.path.join(seed_dir, 'reward_and_steps.png')
        )

        # 3) Time history (par step)
        B = type('B', (), {'time_history': stats['step_times']})
        plot_time_history(
            B, show=False,
            save_path=os.path.join(seed_dir, 'time_history.png')
        )

        # 4) Blocks vs DOF (personnalisé)
        step_list = list(range(1, stats['steps'] + 1))
        fig, ax1 = plt.subplots(figsize=(8, 5))
        ax2 = ax1.twinx()
        ax1.plot(step_list, stats['blocks'], marker='o', label='Blocks')
        ax2.plot(step_list, stats['dofs'],    marker='s', color='r', label='DOF')
        ax1.set_xlabel('Step')
        ax1.set_ylabel('Number of Blocks')
        ax2.set_ylabel('DOF')
        ax2.axhline(TARGET_DOF, linestyle='--', color='gray',
                    label=f'Target DOF = {TARGET_DOF}')
        h1, l1 = ax1.get_legend_handles_labels()
        h2, l2 = ax2.get_legend_handles_labels()
        fig.legend(h1 + h2, l1 + l2, loc='upper right')
        fig.tight_layout()
        fig.savefig(os.path.join(seed_dir, 'blocks_vs_dof.png'))
        plt.close(fig)

        # 5) Visualisation finale de l’environnement
        plot_voxel_environment(
            env, show=False,
            save_path=os.path.join(seed_dir, 'final_voxel_env.png'),
            csv_path=os.path.join(seed_dir, 'final_voxel_env.csv')
        )

        print(f"Seed {seed} → Steps:{stats['steps']} "
              f"Blocks:{stats['final_blocks']} "
              f"DOF:{stats['final_dof']} "
              f"Time:{stats['total_time']:.3f}s")

# -- Après la boucle des seeds : génération des graphiques globaux --------
# Lecture du CSV synthèse
summary_df = pd.read_csv(summary_csv)

# a) Bar‑plot du temps total d’inférence par seed
fig, ax = plt.subplots(figsize=(6, 4))
ax.bar(summary_df['seed'].astype(str), summary_df['total_time'])
ax.set_xlabel('Seed')
ax.set_ylabel('Total inference time (s)')
ax.set_title('Inference Time per Seed')
fig.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, 'inference_time_per_seed.png'))
plt.close(fig)

# b) Graphe récapitulatif (2×2) : Steps, Blocks, DOF, Time
fig, axs = plt.subplots(2, 2, figsize=(10, 8))
summary_df.plot(x='seed', y='steps',        kind='bar', ax=axs[0,0], title='Steps per Seed')
summary_df.plot(x='seed', y='final_blocks', kind='bar', ax=axs[0,1], title='Blocks per Seed')
summary_df.plot(x='seed', y='final_dof',    kind='bar', ax=axs[1,0], title='Final DOF')
summary_df.plot(x='seed', y='total_time',   kind='bar', ax=axs[1,1], title='Time per Seed')
for ax in axs.flat:
    ax.set_xlabel('Seed')
fig.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, 'summary_inference.png'))
plt.close(fig)
