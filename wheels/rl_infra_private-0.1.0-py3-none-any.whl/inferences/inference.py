import os
import time
import random
import pickle
import numpy as np
import csv

from src.agent.QLearningAgent import QLearningAgent
from src.environment.VoxelEnvironment import VoxelEnvironment
from src.plotting.plotting import (
    plot_reward_and_steps,
    plot_time_history,
    plot_blocks_and_dof_dual_axis,
    plot_voxel_environment
)
def run_inference(env, agent, max_steps=10000, target_dof=3):
    state = env.reset()
    # Initialisation des historiques
    rewards    = []
    step_times = []
    blocks     = []
    dofs       = []
    steps      = 0

    t_start = time.time()
    while steps < max_steps:
        ents, adj = env.get_adjacent_entities()
        if not adj:
            break

        t0 = time.time()
        # ε‑greedy
        if random.random() < agent.exploration_rate:
            action = random.choice(adj)
        else:
            action = max(adj, key=lambda a: agent.get_q_value(state, a))
        state, r, done = env.step(action)
        t1 = time.time()

        # MàJ historiques
        rewards.append(r)
        step_times.append(t1 - t0)
        blocks.append(len(env.polyvoxels))
        dofs.append(env.current_dof)

        steps += 1
        if done or env.current_dof <= target_dof:
            break

    total_time = time.time() - t_start

    return {
        'rewards': rewards,
        'step_times': step_times,
        'blocks': blocks,
        'dofs': dofs,
        'steps': steps,
        'total_time': total_time,
        'final_blocks': blocks[-1] if blocks else 0,
        'final_dof': dofs[-1] if dofs else None
    }

# Configuration générale
MODEL_PATH   = '../../models/qlearning_cube6x6x6.pkl'
INPUT_CSV    = '../dataInput/DATAPointsCSV/cube6x6x6.csv'
RESULTS_DIR  = '../results/inference_seeds_cube6x6x6_2'
SEEDS        = [0, 1, 7, 42, 123]
EPSILON      = 0.1  # petite exploration
MAX_STEPS    = 10000
TARGET_DOF   = 3

os.makedirs(RESULTS_DIR, exist_ok=True)

# Pré‐chargement de l'env et du modèle
env_template = VoxelEnvironment(max_polyvoxel_size=60)
env_template.load_points_from_csv(INPUT_CSV)
with open(MODEL_PATH, 'rb') as f:
    q_table_saved = pickle.load(f)

# Fichier de synthèse global
summary_csv = os.path.join(RESULTS_DIR, 'inference_by_seed.csv')
with open(summary_csv, 'w', newline='') as f_csv:
    writer = csv.DictWriter(f_csv, fieldnames=['seed','steps','total_time','final_blocks','final_dof'])
    writer.writeheader()

    for seed in SEEDS:
        # Réinitialisation aléatoire
        random.seed(seed)
        np.random.seed(seed)

        # Cloner l'env
        env = pickle.loads(pickle.dumps(env_template, -1))

        # Créer l’agent
        agent = QLearningAgent(
            state_size=None, action_size=None,
            grid_size_x=env.grid_size_x,
            grid_size_y=env.grid_size_y,
            grid_size_z=env.grid_size_z,
            learning_rate=0.1, discount_rate=0.9,
            exploration_rate=EPSILON,
            exploration_decay=1.0
        )
        agent.q_table = q_table_saved

        # Lancer l’inférence
        stats = run_inference(env, agent)
        stats['seed'] = seed

        # Enregistrer les metrics brutes
        # On ne conserve que les colonnes que l'on a déclarées
        writer.writerow({ k: stats[k] for k in writer.fieldnames })

        # Créer dossier dédié à cette graine
        seed_dir = os.path.join(RESULTS_DIR, f'seed_{seed}')
        os.makedirs(seed_dir, exist_ok=True)

        # 1) Reward & Steps
        class A: pass
        A.rewards_history = [sum(stats['rewards'][:i+1]) for i in range(len(stats['rewards']))]
        A.steps_history   = list(range(1, len(stats['rewards'])+1))
        plot_reward_and_steps(
            A,
            show=False,
            save_path=os.path.join(seed_dir, 'reward_and_steps.png')
        )

        # 2) Time history
        B = type('B', (), {'time_history': stats['step_times']})
        plot_time_history(
            B,
            show=False,
            save_path=os.path.join(seed_dir, 'time_history.png')
        )

        # 3) Blocks vs DOF
        plot_blocks_and_dof_dual_axis(
            stats['blocks'],
            stats['dofs'],
            target_dof=TARGET_DOF,
            show=False,
            save_path=os.path.join(seed_dir, 'blocks_and_dof.png')
        )

        # 4) Visualisation finale de l’environnement
        plot_voxel_environment(
            env,
            show=False,
            save_path=os.path.join(seed_dir, 'final_voxel_env.png'),
            csv_path=os.path.join(seed_dir, 'final_voxel_env.csv')
        )

        print(f"Seed {seed} → Steps:{stats['steps']} Blocks:{stats['final_blocks']} DOF:{stats['final_dof']} Time:{stats['total_time']:.3f}s")
